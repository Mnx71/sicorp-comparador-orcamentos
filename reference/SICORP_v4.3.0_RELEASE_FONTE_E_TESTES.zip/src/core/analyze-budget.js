function cell(row, index) {
  if (index === null || index === undefined || index === "") return "";
  return row?.[Number(index)] ?? "";
}

function compactText(value) {
  return String(value ?? "").trim().replace(/\s+/g, " ");
}

function normalizedHeaderText(value) {
  return compactText(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR");
}

function headerSignature(sheet, headerRowNumber, mapping) {
  const header = sheet.rows?.[Number(headerRowNumber) - 1] ?? [];
  return [
    mapping.code,
    mapping.source,
    mapping.description,
    mapping.unit,
    mapping.quantity,
    mapping.priceWithoutBdi,
    mapping.bdi,
    mapping.priceWithBdi,
  ]
    .filter((index) => index !== null && index !== undefined && index !== "")
    .map(Number)
    .filter(Number.isInteger)
    .map((index) => ({ index, text: normalizedHeaderText(cell(header, index)) }))
    .filter(({ text }) => text !== "");
}

function matchesHeaderSignature(row, signature) {
  return signature.length >= 3
    && signature.every(({ index, text }) => normalizedHeaderText(cell(row, index)) === text);
}

function isHeaderCodeLabel(value) {
  const text = normalizedHeaderText(value);
  return text.length <= 80 && /^(?:cod|codigo)(?:\b|[.:_\-/])/.test(text);
}

function isGenericHeaderCodeLabel(value) {
  const text = normalizedHeaderText(value);
  return text.length <= 80 && /^(?:insumo|item|composicao|servico)(?:\b|[.:_\-/])/.test(text);
}

function isDescriptionHeaderLabel(value) {
  const text = normalizedHeaderText(value);
  return /\bdescricao\b|^servico(?:s)?\b|^insumo(?:s)?\b/.test(text);
}

function isUnitHeaderLabel(value) {
  const text = normalizedHeaderText(value);
  return /^unid(?:ade)?\b|^und\b|\bunidade\b/.test(text);
}

function isQuantityHeaderLabel(value) {
  const text = normalizedHeaderText(value);
  return /\bquantidade\b|^qtd\b|^quant\b|\bcoeficiente\b/.test(text);
}

function isPriceHeaderLabel(value) {
  const text = normalizedHeaderText(value);
  return /\bpreco\b|\bcusto\b|^valor(?:\b|\s*\()|\bvalor\s+unitario\b|\bvalor\s+mediano\b|\b[cp]\.\s*unit\b/.test(text);
}

function isRepeatedHeader(row, signature, mapping) {
  if (matchesHeaderSignature(row, signature)) return true;

  const selectedPriceHeaders = [mapping.priceWithoutBdi, mapping.priceWithBdi]
    .filter((index) => index !== null && index !== undefined && index !== "")
    .map((index) => cell(row, index));

  const codeLabel = cell(row, mapping.code);
  return (isHeaderCodeLabel(codeLabel) || isGenericHeaderCodeLabel(codeLabel))
    && isDescriptionHeaderLabel(cell(row, mapping.description))
    && isUnitHeaderLabel(cell(row, mapping.unit))
    && isQuantityHeaderLabel(cell(row, mapping.quantity))
    && selectedPriceHeaders.some(isPriceHeaderLabel);
}

function rowHasContent(row) {
  return Array.isArray(row) && row.some((value) => compactText(value) !== "");
}

function normalizeCode(value, policy) {
  let code = compactText(value);
  if (policy?.caseInsensitive) code = code.toUpperCase();
  if (policy?.stripSeparators) code = code.replace(/[\s.\-/\\]/g, "");
  return code.replace(/^0+(?=.)/, "");
}

function normalizeSourceKey(value) {
  return compactText(value)
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function parseStrictNumber(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : Number.NaN;

  let text = String(value ?? "").replace(/\u00a0/g, " ").trim();
  if (!text) return Number.NaN;

  text = text
    .replace(/^R\$\s*/i, "")
    .replace(/\s*%$/, "")
    .replace(/\s/g, "");

  if (/^[+\-]?(?:\d+(?:\.\d*)?|\.\d+)[eE][+\-]?\d+$/.test(text)) {
    const scientific = Number(text);
    return Number.isFinite(scientific) ? scientific : Number.NaN;
  }

  const hasComma = text.includes(",");
  const hasDot = text.includes(".");

  if (hasComma && hasDot) {
    const brazilian = /^[+\-]?\d{1,3}(?:\.\d{3})+(?:,\d+)?$/;
    const international = /^[+\-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$/;
    if (brazilian.test(text)) {
      text = text.replace(/\./g, "").replace(",", ".");
    } else if (international.test(text)) {
      text = text.replace(/,/g, "");
    } else {
      return Number.NaN;
    }
  } else if (hasComma) {
    if (!/^[+\-]?\d+(?:,\d+)?$/.test(text)) return Number.NaN;
    text = text.replace(",", ".");
  } else if (hasDot) {
    if (!/^[+\-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)) return Number.NaN;
  } else if (!/^[+\-]?\d+$/.test(text)) {
    return Number.NaN;
  }

  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed : Number.NaN;
}

function parseBdiRate(value) {
  const parsed = parseStrictNumber(value);
  if (!Number.isFinite(parsed)) return Number.NaN;

  const hasPercentSign = String(value ?? "").includes("%");
  const rate = hasPercentSign || Math.abs(parsed) > 1 ? parsed / 100 : parsed;
  return rate > -1 ? rate : Number.NaN;
}

function usablePrice(value) {
  return Number.isFinite(value) && value > 0;
}

function roundMoneyValue(value) {
  if (!Number.isFinite(value)) return Number.NaN;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

function priceForRow(row, mapping) {
  const withoutBdiRaw = cell(row, mapping.priceWithoutBdi);
  let withoutBdi = parseStrictNumber(withoutBdiRaw);
  let withoutBdiSource = usablePrice(withoutBdi) ? "Informado" : "Indisponível";
  const bdiRaw = cell(row, mapping.bdi);
  const bdiRate = parseBdiRate(bdiRaw);
  const withBdiRaw = cell(row, mapping.priceWithBdi);
  let withBdi = parseStrictNumber(withBdiRaw);
  let withBdiSource = usablePrice(withBdi) ? "Informado" : "Indisponível";

  if (!usablePrice(withoutBdi) && usablePrice(withBdi) && Number.isFinite(bdiRate)) {
    withoutBdi = roundMoneyValue(withBdi / (1 + bdiRate));
    withoutBdiSource = "Calculado com BDI";
  }

  if (!usablePrice(withBdi) && usablePrice(withoutBdi) && Number.isFinite(bdiRate)) {
    withBdi = roundMoneyValue(withoutBdi * (1 + bdiRate));
    withBdiSource = "Calculado sem BDI + BDI";
  }

  return {
    withoutBdiRaw,
    withoutBdi,
    withoutBdiSource,
    bdiRaw,
    bdiRate,
    withBdiRaw,
    withBdi,
    withBdiSource,
  };
}

function reviewPriceText(price) {
  return [price.withoutBdiRaw, price.withBdiRaw]
    .filter((value) => compactText(value) !== "")
    .map(compactText)
    .join(" / ");
}

/**
 * Analisa uma aba canônica de orçamento sem depender de DOM, File ou readers.
 *
 * O checkpoint dev.10 cobre uma linha válida com preços informados e a remoção
 * de linhas estruturais como Título/categoria ou com identidade completa e
 * quantidade inválida como Item incompleto. Também cobre os cálculos entre
 * preços com e sem BDI, cabeçalhos repetidos por assinatura ou rótulos
 * equivalentes, linhas anteriores ao cabeçalho e números com separadores
 * brasileiros ou em notação científica. Os demais casos serão acrescentados
 * separadamente.
 */
export function analyzeBudget({
  fileName,
  sheet,
  headerRowNumber,
  mapping,
  codePolicy,
}) {
  const items = [];
  const reviewRows = [];
  const headerRowIndex = Math.max(0, Number(headerRowNumber) - 1);
  const firstDataRowIndex = headerRowIndex + 1;
  const repeatedHeaderSignature = headerSignature(sheet, headerRowNumber, mapping);

  for (let rowIndex = 0; rowIndex < headerRowIndex; rowIndex += 1) {
    const row = sheet.rows[rowIndex] ?? [];
    if (!rowHasContent(row)) continue;

    const price = priceForRow(row, mapping);
    reviewRows.push({
      treatment: "Removida",
      reason: "Antes do cabeçalho",
      reasonDetails: [
        "Linha anterior ao cabeçalho selecionado; exibida apenas como contexto na pré-visualização.",
      ],
      origin: {
        fileName,
        sheet: sheet.name,
        rowNumber: rowIndex + 1,
      },
      values: {
        code: cell(row, mapping.code),
        source: cell(row, mapping.source),
        description: cell(row, mapping.description),
        unit: cell(row, mapping.unit),
        quantity: cell(row, mapping.quantity),
        price: reviewPriceText(price),
      },
    });
  }

  for (let rowIndex = firstDataRowIndex; rowIndex < sheet.rows.length; rowIndex += 1) {
    const row = sheet.rows[rowIndex] ?? [];
    if (!rowHasContent(row)) continue;

    const codeRaw = cell(row, mapping.code);
    const code = normalizeCode(codeRaw, codePolicy);
    const sourceRaw = cell(row, mapping.source);
    const source = compactText(sourceRaw);
    const sourceKey = normalizeSourceKey(source);
    const descriptionRaw = cell(row, mapping.description);
    const description = compactText(descriptionRaw);
    const unitRaw = cell(row, mapping.unit);
    const unit = compactText(unitRaw);
    const quantityRaw = cell(row, mapping.quantity);
    const quantity = parseStrictNumber(quantityRaw);
    const price = priceForRow(row, mapping);

    if (isRepeatedHeader(row, repeatedHeaderSignature, mapping)) {
      reviewRows.push({
        treatment: "Removida",
        reason: "Cabeçalho repetido",
        reasonDetails: [],
        origin: {
          fileName,
          sheet: sheet.name,
          rowNumber: rowIndex + 1,
        },
        values: {
          code: codeRaw,
          source: sourceRaw,
          description: descriptionRaw,
          unit: unitRaw,
          quantity: quantityRaw,
          price: reviewPriceText(price),
        },
      });
      continue;
    }

    const problems = [];

    if (!code) problems.push("Código ausente ou inválido");
    if (!description) problems.push("Descrição ausente");
    if (!unit) problems.push("Unidade ausente");
    if (!Number.isFinite(quantity) || quantity < 0) {
      problems.push("Quantidade ausente, negativa ou não numérica");
    }
    if (!sourceKey) problems.push("Fonte/base de referência ausente");
    if (!usablePrice(price.withoutBdi)) {
      problems.push("Preço unitário utilizável não encontrado");
    }

    const structural = !code || !description || !unit;
    if (problems.length) {
      reviewRows.push({
        treatment: "Removida",
        reason: structural ? "Título/categoria" : "Item incompleto",
        reasonDetails: problems,
        origin: {
          fileName,
          sheet: sheet.name,
          rowNumber: rowIndex + 1,
        },
        values: {
          code: codeRaw,
          source: sourceRaw,
          description: descriptionRaw,
          unit: unitRaw,
          quantity: quantityRaw,
          price: reviewPriceText(price),
        },
      });
      continue;
    }

    items.push({
      origin: {
        fileName,
        sheet: sheet.name,
        rowNumber: rowIndex + 1,
      },
      codeRaw,
      code,
      source,
      sourceKey,
      description,
      unit,
      quantityRaw,
      quantity,
      price,
    });
  }

  return {
    items,
    reviewRows,
    stats: {
      accepted: items.length,
      reviewed: reviewRows.length,
    },
  };
}
