import assert from "node:assert/strict";
import test from "node:test";

import { integratePriceSourceCentralHtml } from "../../src/build/integrate-price-source-central-html.js";

const syntheticBaseline = `<!doctype html>
<html>
<head><style>
  .existing { color: blue; }
</style></head>
<body>
  <h1>SICORP v4 — Comparação por Fonte, Código e Descrição</h1>
  <span class="offline-pill">● Versão 4.0.5 · Curva ABC · Offline</span>
  <nav>
    <button class="step-button" data-step-target="2" disabled>Bases</button>
    <button class="step-button" data-step-target="3" disabled>Comparação</button>
  </nav>
    <div id="sourceGrid" class="grid">
  <section class="wizard-page" data-page="1">
            <div class="source-identifiers-panel">
              <div class="source-identifiers-head">
                <strong>Identificadores de fonte encontrados</strong>
                <span class="small">Essas opções serão usadas ao configurar as bases.</span>
              </div>
              <div id="projectSourceIdentifiers" class="source-identifiers" aria-live="polite"></div>
            </div>
    <button id="projectNextBtn" data-go-page="2" disabled>Continuar para as bases →</button>
  </section>
  <section class="wizard-page page-hidden" data-page="2">
    <h2>2. Adicione uma base referencial</h2>
    <div class="content">
      <p class="section-intro">Adicione as bases uma por uma e associe cada uma à fonte correspondente encontrada no orçamento. Linhas estruturais são separadas dos itens; preços ausentes, não numéricos, zero ou negativos permanecem auditáveis e, na comparação, o item será tratado como “Não encontrado”.</p>
      <span class="small">Linhas anteriores + cabeçalho + até 11 itens</span>
      <span class="small">Linhas anteriores + cabeçalho + até 11 itens</span>
      <label id="baseDropzone">
        <input id="baseFile" type="file" accept=".xlsx,.xls,.csv,.txt" />
        <span>SINAPI, SICRO, ORSE ou outra planilha tratada</span>
      </label>
      <button id="basesNextBtn" data-go-page="3" disabled>Continuar para comparação →</button>
    </div>
  </section>
    </div>
  <script>
    "use strict";
    function previewVisibleRowIndexes(rowCount, headerIndex, itemRowIndexes = null) {
      const safeRowCount = Math.max(0, Number(rowCount) || 0);
      if (!safeRowCount) return [];
      const safeHeaderIndex = Math.min(safeRowCount - 1, Math.max(0, Number(headerIndex) || 0));
      const beforeHeader = Array.from({ length: safeHeaderIndex }, (_, index) => index);
      if (Array.isArray(itemRowIndexes)) {
        const acceptedItems = itemRowIndexes
          .filter((rowIndex) => rowIndex > safeHeaderIndex && rowIndex < safeRowCount)
          .slice(0, 11);
        return [...beforeHeader, safeHeaderIndex, ...acceptedItems];
      }
      const end = Math.min(safeRowCount, safeHeaderIndex + 12);
      return Array.from({ length: end }, (_, index) => index);
    }

    function renderPreview() {}
    function renderResults() {
          const numeric = ["money", "percent", "integer"].includes(column.type);
    }
    function formatComparisonDisplayValue(value, type) {
        if (type === "integer") return String(Math.round(value));
    }
    function comparisonColumnDefinitions() {
      return [
        { key: "projectBdiRate", header: "BDI", type: "percent", width: 13, value: (r) => Number.isFinite(r.projectBdiRate) ? r.projectBdiRate : r.projectBdiRaw, sortValue: (r) => r.projectBdiRate },
      ];
    }
    function refreshWizardState() {
      const hasProject = Boolean(state.projectWorkbook);
      const hasProjectMapping = projectConfigurationValid();
      const hasBases = state.bases.length > 0;
      const hasBlockingConflicts = state.conflicts.length > 0;
      for (const button of document.querySelectorAll(".step-button")) {
        const step = Number(button.dataset.stepTarget);
        button.disabled = step === 2 ? !(hasProject && hasProjectMapping)
          : step === 3 ? !(hasProject && hasProjectMapping && hasBases && !hasBlockingConflicts)
          : false;
        const completed = step === 1 ? (hasProject && hasProjectMapping)
          : step === 2 ? (hasBases && !hasBlockingConflicts)
          : state.results.length > 0;
        button.classList.toggle("completed", completed);
        button.classList.toggle("active", step === state.currentPage);
      }
      el("projectNextBtn").disabled = !(hasProject && hasProjectMapping);
      el("basesNextBtn").disabled = !hasBases || hasBlockingConflicts;
    }

    function goToPage(page) {
      const target = Number(page);
      if ((target === 2 || target === 3) && (!state.projectWorkbook || !projectConfigurationValid())) {
        showError("Carregue e configure o orçamento antes de continuar.");
        return;
      }
      if (target === 3 && (!state.projectWorkbook || !state.bases.length)) {
        showError("Carregue o orçamento e adicione pelo menos uma base antes da comparação.");
        return;
      }
      if (target === 3 && state.conflicts.length) {
        showError("Existem duplicidades bloqueantes entre as bases. Corrija ou remova as ocorrências com unidade ou preço divergente antes de continuar.");
        return;
      }
      clearError();
      state.currentPage = target;
      for (const pageEl of document.querySelectorAll(".wizard-page")) {
        pageEl.classList.toggle("page-hidden", Number(pageEl.dataset.page) !== target);
      }
      refreshWizardState();
      if (typeof window.scrollTo === "function") window.scrollTo({ top: 0, behavior: "smooth" });
    }
    function wireEvents() {}
    wireEvents();
  </script>
</body>
</html>`;

test("integração inclui a central uma única vez e preserva o carregamento manual", () => {
  const output = integratePriceSourceCentralHtml(syntheticBaseline);

  assert.equal(output.match(/id="priceSourceSearch"/g)?.length, 1);
  assert.equal(output.match(/id="priceSourceLinks"/g)?.length, 1);
  assert.equal(output.match(/id="priceSourceUnknown"/g)?.length, 1);
  assert.equal(output.match(/installPriceSourceCentralUi\s*\(/g)?.length, 1);
  assert.match(output, /id="baseDropzone"/);
  assert.match(output, /id="priceSourceEditorDialog"/);
  assert.match(output, /id="priceSourceEditorClose"/);
  assert.match(output, /id="priceSourceRemove"[^>]*>Excluir base</);
  assert.doesNotMatch(output, /id="priceSourceRestore"/);
  assert.doesNotMatch(output, /Restaurar esta base/);
  assert.match(output, /id="blockingDialog"/);
  assert.match(output, /id="blockingDialogReturn"[^>]*>Retornar</);
  assert.match(output, /function showBlockingIssue/);
  assert.doesNotMatch(output, /id="projectNextBtn"[^>]*disabled/);
  assert.doesNotMatch(output, /id="basesNextBtn"[^>]*disabled/);
  assert.doesNotMatch(output, /data-step-target="2"[^>]*disabled/);
  assert.doesNotMatch(output, /data-step-target="3"[^>]*disabled/);
  assert.doesNotMatch(output, /Gerenciar links e bases/);
  assert.doesNotMatch(output, /id="priceSourceEditorSelect"/);
  assert.match(output, /id="priceSourceUrl" type="text" required/);
  assert.match(output, /id="priceSourceUrl"[^>]*placeholder="https:\/\/"/);
  assert.doesNotMatch(output, /Pode ser informado com ou sem https:\/\//);
  assert.doesNotMatch(output, /id="priceSourceUrl" type="url"/);
  assert.match(output, /Exportar JSON/);
  assert.match(output, /Importar JSON/);
  assert.match(output, /accept="\.xlsx,\.xls,\.csv,\.txt,\.orse"/);
  assert.match(output, /Planilhas XLSX, XLS, CSV, TXT ou ORSE/);
  assert.doesNotMatch(output, /Identificadores de fonte encontrados/);
  assert.match(output, /id="projectSourceIdentifiers" class="hidden"/);
  assert.match(output, /header: "Quantidade"/);
  assert.match(output, /"integer", "quantity"/);
  assert.equal(output.match(/Até 2 linhas anteriores \+ cabeçalho \+ até 11 itens/g)?.length, 2);
  assert.doesNotMatch(output, /Linhas anteriores \+ cabeçalho \+ até 11 itens/);
  assert.match(output, /Linhas que não são consideradas itens são identificadas e removidas da planilha/);
  assert.doesNotMatch(output, /Linhas estruturais são separadas dos itens/);
  assert.match(output, /\.price-source-unknown \{[\s\S]*?display: inline-block;[\s\S]*?width: fit-content;[\s\S]*?background: #eff6ff;[\s\S]*?color: #1d4ed8;/);
  assert.doesNotMatch(output, /\.price-source-match-badge\.family/);

  const centralIndex = output.indexOf('id="priceSourceCentral"');
  const introductionIndex = output.indexOf("Linhas que não são consideradas itens");
  const dropzoneIndex = output.indexOf('id="baseDropzone"');
  assert.ok(centralIndex < introductionIndex && introductionIndex < dropzoneIndex);

  const functionStart = output.indexOf("function previewVisibleRowIndexes");
  const functionEnd = output.indexOf("\n\n    function renderPreview", functionStart);
  const functionSource = output.slice(functionStart, functionEnd);
  const previewVisibleRowIndexes = Function(`${functionSource}; return previewVisibleRowIndexes;`)();
  assert.deepEqual(previewVisibleRowIndexes(30, 7, [8, 9, 20]), [5, 6, 7, 8, 9, 20]);
  assert.deepEqual(previewVisibleRowIndexes(30, 7), [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]);
});

test("integração identifica a versão e rejeita âncora ausente ou duplicada", () => {
  const output = integratePriceSourceCentralHtml(syntheticBaseline);
  assert.match(output, /SICORP v4\.3/);
  assert.match(output, /Versão 4\.3\.0/);

  assert.throws(
    () => integratePriceSourceCentralHtml(syntheticBaseline.replace('id="baseDropzone"', 'id="outraCoisa"')),
    /Âncora única.*central/i,
  );
  assert.throws(
    () => integratePriceSourceCentralHtml(`${syntheticBaseline}\n<label id="baseDropzone"></label>`),
    /Âncora única.*central/i,
  );
});
