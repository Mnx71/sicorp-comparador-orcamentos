import assert from "node:assert/strict";
import test from "node:test";

import {
  consolidateSingleHtml,
  insertBeforeUniqueAnchor,
} from "../../src/build/consolidate-single-html.js";

const baseline = [
  "prefix",
  "    async function loadWorkbook(file) {",
  "      return 'legado-reader';",
  "    }",
  "",
  "    function sheetByName() { return 'preservada-reader'; }",
  "    function compare() {",
  "      return 'legado-comparacao';",
  "    }",
  "",
  "    function resultClass() { return 'preservada-comparacao'; }",
  "    function exportCsv() {",
  "      return 'legado-csv';",
  "    }",
  "",
  "    function escapeXml() { return 'preservada-exportacao'; }",
  "    function exportXlsx() {",
  "      return 'legado-xlsx';",
  "    }",
  "",
  "    function buildClipboardText() { return 'preservada-clipboard'; }",
  "    async function copyTable() {",
  "      return 'legado-clipboard';",
  "    }",
  "",
  "    function clearResults() { return 'preservada-resultado'; }",
  "suffix",
].join("\n");

const integrations = {
  readerIntegration: "    /* READER */\n    async function loadWorkbook(file) { return 'canônico'; }\n",
  comparisonIntegration: "    /* COMPARE */\n    function compare() { return 'canônico'; }\n",
  exportIntegration: [
    "    /* EXPORT */",
    "    function exportCsv() { return 'canônico'; }",
    "    function exportXlsx() { return 'canônico'; }",
    "    async function copyTable() { return 'canônico'; }",
    "",
  ].join("\n"),
};

test("consolidação substitui os cinco fallbacks e preserva as funções vizinhas", () => {
  const output = consolidateSingleHtml(baseline, integrations);

  assert.match(output, /READER[\s\S]*loadWorkbook\(file\).*canônico/);
  assert.match(output, /COMPARE[\s\S]*function compare\(\).*canônico/);
  assert.match(output, /EXPORT[\s\S]*function exportCsv\(\).*canônico/);
  assert.match(output, /function exportXlsx\(\).*canônico/);
  assert.match(output, /async function copyTable\(\).*canônico/);
  assert.doesNotMatch(output, /legado-/);
  assert.match(output, /preservada-reader/);
  assert.match(output, /preservada-comparacao/);
  assert.match(output, /preservada-exportacao/);
  assert.match(output, /preservada-clipboard/);
  assert.match(output, /preservada-resultado/);
});

test("consolidação rejeita uma âncora ausente", () => {
  assert.throws(
    () => consolidateSingleHtml(baseline.replace("function compare()", "function comparar()"), integrations),
    /Âncora inicial única da comparação não encontrada/,
  );
});

test("consolidação rejeita uma âncora duplicada", () => {
  assert.throws(
    () => consolidateSingleHtml(`${baseline}\n    function compare() {}`, integrations),
    /Âncora inicial única da comparação não encontrada/,
  );
});

test("inserção do núcleo preserva sequências dólar-e-comercial literalmente", () => {
  const source = "antes\n  <script>\n    código legado\ndepois";
  const core = 'formatCode="&quot;R$&quot; #,##0.00"';

  const output = insertBeforeUniqueAnchor(source, "  <script>\n", core);

  assert.match(output, /R\$&quot;/);
  assert.equal(output.match(/  <script>/g)?.length, 1);
  assert.equal(output, `antes\n${core}  <script>\n    código legado\ndepois`);
});
