# SICORP v4.3 — Leitor integrado de arquivos ORSE

Release final `v4.3.0`, desenvolvida sobre a release `v4.2.0`.

## Objetivo da v4.3

- aceitar arquivos `.ORSE` diretamente na área de carregamento de bases;
- reutilizar as regras homologadas do Conversor ORSE para Excel v1.3.0;
- extrair somente materiais e serviços ORSE ativos, excluindo registros SINAPI,
  equipamentos e itens inativos;
- preservar itens ativos sem preço com custo vazio;
- carregar internamente as abas **Insumos** e **Servicos** no mesmo fluxo manual
  já usado pelas demais bases;
- baixar automaticamente uma pasta de trabalho com **Resumo**, **Insumos** e
  **Servicos**, usando o nome original acrescido de `_ORSE.xlsx`;
- reproduzir no XLSX a identidade visual do Conversor ORSE v1.3.0, incluindo
  cores, fontes, bordas, larguras, filtros, congelamento e formatos numéricos;
- manter os botões de navegação acionáveis e explicar cada impedimento em uma
  janela com a ação **Retornar**;
- manter o comparador aprovado na v4.2.0 e simplificar a portabilidade da
  Central de Bases.

## Funcionalidades preservadas da v4.2

- incluir, na página **Bases**, uma Central com 20 portais federais, estaduais
  e do Distrito Federal;
- exibir inicialmente apenas as bases identificadas no orçamento e oferecer
  **Ver outras** para abrir o catálogo completo;
- reconhecer fontes sem diferenciar caixa, acentos ou separadores, usando
  exclusivamente a sigla atual de cada card e sem manter aliases;
- tratar a primeira parte de qualquer sigla como uma pesquisa genérica:
  `DER` e `SEINFRA` sugerem todas as variantes cadastradas, enquanto
  uma sigla intermediária, como `DER-ES`, sugere todas as especializações
  cadastradas, enquanto `DER-ES_Edif` e `DER-ES_Rodo` permanecem específicas;
- reconhecer complementos de estado ou ano, como `CAESB-DF` e `CAESB-2026`,
  mesmo quando o card se chama apenas `CAESB`;
- apresentar toda identificação no card como **Sugestão para “X”** e listar
  separadamente as fontes não identificadas automaticamente;
- pesquisar por sigla ou órgão responsável, sem diferenciar acentos ou caixa;
- abrir cada portal somente após ação explícita do usuário;
- permitir editar cada base pela engrenagem do próprio card e adicionar uma
  entrada pelo card **+**, sempre com ordenação alfabética;
- exigir o preenchimento do link, aceitar texto livre no campo e preservar
  alterações no `localStorage`;
- permitir exportar e importar um JSON portátil, legível e com o catálogo
  completo; cada entrada pública contém somente `sigla`, `orgao` e `link`, e a
  compatibilidade é reconhecida pelo formato e por esses campos, sem número de
  versão;
- gerar e manter os identificadores técnicos somente no estado interno, sem
  expô-los ao usuário, inclusive para novas bases;
- impedir siglas duplicadas, permitir excluir qualquer base e concentrar a
  restauração do catálogo na ação global **Restaurar padrão**;
- limitar as pré-visualizações do orçamento e das bases às duas linhas
  imediatamente anteriores ao cabeçalho;
- ocultar o painel visual de identificadores de fonte do orçamento, preservando
  a identificação interna usada para sugerir as bases;
- exibir a quantidade entre **BDI** e **Valor total com BDI** na tabela e em
  CSV, XLSX e texto copiado;
- manter as três ações do JSON compactas e na mesma linha, manter **Ver outras
  (0)** acessível quando todas as bases forem identificadas e exibir o card
  **Nova base** somente após abrir o catálogo completo;
- mostrar confirmações de edição, inclusão, exclusão, restauração, importação e
  exportação por cerca de três segundos, limpando-as ao mudar de contexto;
- manter o carregamento manual e todo o comparador offline independentes da
  Central de links;
- preservar a v4.0.5 e a v4.1.0 como artefatos imutáveis.

O catálogo padrão mantém o link do protótipo para `DER-MG / SICOR` e contém
somente bases federais, estaduais e do Distrito Federal. As bases municipais
`SCO-RIO`, `SIURB`, `SUDECAP` e `CASAN` foram retiradas. `DER-PB` e `SEOP-PA`
foram adicionadas. `DER-ES` foi dividido em `DER-ES_Edif` e `DER-ES_Rodo`, com
links próprios. A identificação não consulta o nome do órgão nem regras fixas
por base: renomear ou criar um card recalcula as sugestões imediatamente.

## Baseline estrutural preservada

- preservar a v4.0.5 como baseline imutável;
- estabelecer fonte, testes, build e `dist` separados;
- manter os seams públicos de leitura, análise, catálogo, comparação e
  exportação, além do adaptador de transição e da ponte da interface;
- gerar um único HTML offline com o carregamento de XLS, XLSX e CSV, **Comparar**,
  **CSV**, **XLSX** e **Copiar** conectados ao núcleo canônico;
- consolidar essas cinco entradas, removendo do artefato os respectivos
  fallbacks legados já substituídos e homologados no checkpoint anterior;
- montar o HTML único sem interpretar sequências como `$&` presentes no código
  incorporado, preservando o XML da exportação XLSX.

Esta linha mantém a interface e o fluxo interno homologados na v4.1.0, com
fonte modular, testes automatizados e build reproduzível do HTML único.

## Comandos

```bash
npm test
npm run build
npm run validate
npm run check
npm run regression:fixtures
npm run regression:real
npm run regression:orse
npm run qa:export
npm run qa:built-export
npm run qa:built-orse
npm run qa:browser
```

`npm run check` executa a suíte rápida, gera o HTML único e valida a paridade
estrutural com a baseline.

`npm run regression:real` abre as quatro planilhas de homologação pelo reader
canônico e executa o fluxo leitura → orçamento → catálogo → comparação → visão
→ exportação. Ele fica separado da suíte rápida por ser intencionalmente mais
pesado.

`npm run regression:orse` converte o arquivo real `20260601-00.ORSE`, verifica
8.087 insumos, 9.931 serviços e reabre o XLSX gerado com as três abas. O comando
`npm run qa:built-orse` repete as contagens usando o núcleo extraído do próprio
HTML distribuído.

`npm run regression:fixtures` usa cinco planilhas compactas e um oráculo
independente para validar 26 casos aceitos, 11 revisões do orçamento,
duplicidades, conflitos, classificações, totais e exportação. As instruções e a
matriz estão em `testkit/README_TESTKIT.md` e
`testkit/fixtures/00_MATRIZ_CASOS_TESTE_v4.1.0.xlsx`.

`npm run qa:export` gera um CSV e um XLSX sintéticos com os quatro estados de
comparação para inspeção do artefato. `npm run qa:built-export` executa o núcleo
extraído do HTML final e valida o `styles.xml` realmente distribuído.
`npm run qa:browser` automatiza o fluxo da interface com arquivos CSV pequenos e
requer Playwright com Chromium instalado; o runtime do navegador não é
incorporado ao projeto.

O mesmo fluxo pode ser executado sem `npm`:

```bash
node scripts/check.mjs
```

## Estado atual

- seams aprovados e iniciados: `analyzeBudget`, `prepareReferenceCatalog` e
  `compareBudgetToCatalog`;
- leitura: `readWorkbookFile` converte XLS, XLSX, CSV, TSV e TXT delimitado para
  o mesmo workbook canônico, sem depender de DOM, `FileReader` ou estado global;
  o runtime de planilhas offline é recebido por injeção nos formatos binários;
- caracterizações: linha válida, linha estrutural classificada como
  `Título/categoria`, quantidade inválida classificada como `Item incompleto`,
  cálculos entre preços com e sem BDI, `Cabeçalho repetido` por assinatura ou
  rótulos equivalentes, `Antes do cabeçalho`, número brasileiro com milhar e
  notação científica;
- catálogo de referência: linha válida canônica e linhas com identidade completa
  e preço ausente, não numérico, zero ou negativo mantidas com alertas
  auditáveis; linhas sem identidade, cabeçalhos repetidos e conteúdo anterior ao
  cabeçalho são removidos com revisão rastreável; duplicidades equivalentes são
  consolidadas e divergências de unidade ou preço geram conflitos bloqueantes;
- comparação: correspondência por fonte e código, resolução por descrição
  normalizada quando o código se repete, prioridade para preço utilizável,
  tolerância absoluta, estados `Abaixo`, `Igual`, `Acima` e `Não encontrado`,
  motivos de indisponibilidade e bloqueio por conflitos do catálogo; quantidade,
  total com BDI, participação, consolidações financeiras completas ou parciais e
  ordenação estável da Curva ABC;
- adaptação de apresentação: os resultados canônicos são convertidos para os
  campos já consumidos por tabela, cartões e exportações, preservando todas as
  origens de bases equivalentes e sem modificar o modelo de entrada;
- integração: `runComparisonFromLegacyState` traduz workbooks, mapeamentos,
  bases, tolerância e política de códigos da interface, executa os três seams e
  entrega a visão adaptada ao renderizador existente;
- exportação: `prepareComparisonExport` recebe apenas os resultados já filtrados
  e ordenados e produz uma tabela tipada de 18 colunas, CSV em formato brasileiro,
  XLSX offline e texto tabulado para clipboard, sem depender de DOM ou workbooks;
- suíte rápida: 105 testes, incluindo 20 testes da Central e seis testes do
  conversor ORSE sem arquivo real;
- regressão ORSE real: 8.087 insumos materiais ativos e 9.931 serviços ativos;
  todos os insumos possuem preço, e dois serviços ativos permanecem sem preço;
- test kit compacto: seis XLSX, 26 resultados comparados, 13 revisões do
  catálogo, quatro indisponibilidades exibidas como `Não encontrado`, dois
  conflitos bloqueantes e exportação de 18 colunas, todos aprovados;
- build: HTML único com leitura, análise, catálogo, comparação, adaptação, ponte
  e exportação incorporados localmente;
- interface: o carregamento de arquivos, **Comparar**, **CSV**, **XLSX** e
  **Copiar** usam entradas canônicas únicas; `loadWorkbookLegacy`,
  `compareLegacy`, `exportCsvLegacy`, `exportXlsxLegacy` e `copyTableLegacy`
  não existem mais no artefato;
- regressão real: aprovada com as quatro planilhas e 424 linhas exportadas, fora
  do ciclo rápido;
- QA do artefato: o núcleo extraído do próprio HTML final gerou um XLSX cujo
  `styles.xml` é XML válido, contém o formato monetário `R$` intacto e não
  contém o bloco `<script>` indevido; o arquivo foi reimportado e renderizado
  com 18 colunas, tipos numéricos e cores preservados;
- homologação interativa: aprovada manualmente no navegador do usuário para o
  `dev.23` com as quatro planilhas reais; o cabeçalho do orçamento foi
  corretamente detectado na linha 2, os 424 resultados foram preservados e os
  241 itens exibidos como `Não encontrados` agregam, intencionalmente, 158
  referências ausentes e 83 referências sem preço utilizável. A exportação CSV
  foi confirmada. Nos `dev.24` e `dev.25`, o Excel do Windows solicitou
  recuperação do XLSX e removeu as cores. A mensagem detalhada permitiu localizar
  a causa no montador do HTML, corrigida no `dev.26`. A correção foi aprovada
  manualmente no Excel do Windows: o XLSX abriu sem reparo e preservou as cores.
  O `rc.1` também foi aprovado pelo usuário. O `rc.2` reformulou a edição
  contextual e a portabilidade da Central de Bases. O `rc.3` reuniu os ajustes
  de pré-visualização, resultados, navegação, ORSE e catálogo. O `rc.4` exigiu o
  link oficial, simplificou o JSON portátil e retirou a CASAN. O `rc.5` adicionou
  `DER-PB` e `SEOP-PA`, reconhecimento sem separadores, sugestões por família e
  a exibição das fontes não reconhecidas. O `rc.6` eliminou aliases, generalizou
  a pesquisa para qualquer sigla atual, aceita complementos de estado e ano,
  mantém **Ver outras (0)** acessível e torna as confirmações temporárias. A
  release final padroniza os selos como sugestões azuis e divide os dois
  referenciais do DER-ES.

O arquivo `sicorp_comparador_orcamento_v4.3.0.html` em `dist` é a release final.

## Estrutura

```text
baseline/   referência imutável da v4.0.5
src/core/   deep modules de domínio, incluindo o registro da Central
src/ui/     integração da Central com DOM, localStorage e JSON
src/build/  transformação estrutural do HTML único
tests/      testes por seams públicos
testkit/    planilhas compactas, matriz, oráculo e instruções de regressão
scripts/    build e validação reproduzíveis
dist/       HTML único gerado
docs/       decisões e evidências do checkpoint
```

## Baseline

`baseline/sicorp_comparador_orcamento_v4.0.5.html`

SHA-256 esperado:

```text
be2c883baf4b4611d9ea2cefced7c4973587dfa8aac952271a6e21ddc389a7b8
```

Consulte `docs/RELEASE_v4.3.0.md`, `docs/RELEASE_v4.2.0.md` e
`docs/DECISOES_ARQUITETURA.md` antes de ampliar a implementação.
