import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

import {
  baseAFixture,
  baseBFixture,
  budgetFixture,
  colors,
  conflictBaseFixture,
  coverageRows,
  generalBaseFixture,
} from "./fixture-spec.js";

const sourceDirectory = path.dirname(fileURLToPath(import.meta.url));
const testkitRoot = process.env.SICORP_TESTKIT_ROOT
  ? path.resolve(process.env.SICORP_TESTKIT_ROOT)
  : sourceDirectory;
const fixtureDirectory = path.join(testkitRoot, "fixtures");
const previewDirectory = path.join(testkitRoot, "previews");

await fs.mkdir(fixtureDirectory, { recursive: true });
await fs.mkdir(previewDirectory, { recursive: true });

function columnName(columnCount) {
  let name = "";
  let value = columnCount;
  while (value > 0) {
    const remainder = (value - 1) % 26;
    name = String.fromCharCode(65 + remainder) + name;
    value = Math.floor((value - 1) / 26);
  }
  return name;
}

function styleHeader(range) {
  range.format = {
    fill: colors.blue,
    font: { bold: true, color: colors.white },
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: "#B4C6E7" },
  };
}

function styleData(range) {
  range.format = {
    verticalAlignment: "top",
    wrapText: true,
    borders: { preset: "all", style: "thin", color: "#D9E2F3" },
  };
}

function styleTitle(sheet, columnCount, title) {
  const endColumn = columnName(columnCount);
  sheet.mergeCells(`A1:${endColumn}1`);
  sheet.getRange("A1").values = [[title]];
  sheet.getRange(`A1:${endColumn}1`).format = {
    fill: colors.navy,
    font: { bold: true, color: colors.white, size: 15 },
    verticalAlignment: "center",
  };
  sheet.getRange(`A1:${endColumn}1`).format.rowHeight = 30;
}

function applyFixtureWidths(sheet, widths) {
  for (const [index, width] of widths.entries()) {
    sheet.getRange(`${columnName(index + 1)}:${columnName(index + 1)}`).format.columnWidth = width;
  }
}

function colorFixtureRows(sheet, firstDataRow, rows, columnCount) {
  const endColumn = columnName(columnCount);
  for (const [index, row] of rows.entries()) {
    const id = String(Array.isArray(row) ? row[0] : row.id ?? "");
    const rowNumber = firstDataRow + index;
    const range = sheet.getRange(`A${rowNumber}:${endColumn}${rowNumber}`);
    if (/^(REV|B-REV|CFL)/.test(id)) range.format.fill = colors.red;
    else if (/^(ALR)/.test(id)) range.format.fill = colors.amber;
    else if (/^(IGN)/.test(id)) range.format.fill = colors.gray;
    else if (/^(DUP)/.test(id)) range.format.fill = colors.lightBlue;
    else range.format.fill = colors.green;
  }
}

function writeFixtureSheet(workbook, {
  sheetName,
  title,
  headerRow,
  header,
  rows,
  formulaRows = [],
}) {
  const sheet = workbook.worksheets.add(sheetName);
  sheet.showGridLines = false;
  const normalizedRows = rows.map((entry) => Array.isArray(entry) ? entry : entry.row);
  const columnCount = header.length;
  const endColumn = columnName(columnCount);

  if (headerRow === 2) {
    styleTitle(sheet, columnCount, title);
  }

  sheet.getRangeByIndexes(headerRow - 1, 0, 1, columnCount).values = [header];
  styleHeader(sheet.getRange(`${"A"}${headerRow}:${endColumn}${headerRow}`));
  sheet.getRange(`${"A"}${headerRow}:${endColumn}${headerRow}`).format.rowHeight = 34;

  if (normalizedRows.length) {
    const dataStart = headerRow + 1;
    const dataEnd = dataStart + normalizedRows.length - 1;
    sheet.getRangeByIndexes(dataStart - 1, 0, normalizedRows.length, columnCount).values = normalizedRows;
    styleData(sheet.getRange(`A${dataStart}:${endColumn}${dataEnd}`));
    colorFixtureRows(sheet, dataStart, rows, columnCount);
  }

  for (const formulaRow of formulaRows) {
    sheet.getRange(`B${formulaRow.rowNumber}`).formulas = [[formulaRow.formula]];
  }

  const lastUsedRow = headerRow + normalizedRows.length;
  sheet.getRange(`A${headerRow}:B${lastUsedRow}`).setNumberFormat("@");

  sheet.freezePanes.freezeRows(headerRow);
  applyFixtureWidths(sheet, columnCount === 10
    ? [14, 16, 19, 31, 12, 13, 16, 12, 16, 46]
    : [14, 17, 34, 13, 16, 48]);
  return sheet;
}

function createBudgetWorkbook() {
  const workbook = Workbook.create();
  const formulaRows = budgetFixture.rows
    .map((entry, index) => ({
      rowNumber: budgetFixture.headerRow + 1 + index,
      formula: entry.formulaCode,
    }))
    .filter((entry) => entry.formula);
  writeFixtureSheet(workbook, {
    ...budgetFixture,
    formulaRows,
  });
  return workbook;
}

function createGeneralBaseWorkbook() {
  const workbook = Workbook.create();
  writeFixtureSheet(workbook, generalBaseFixture);
  return workbook;
}

function createBaseAWorkbook() {
  const workbook = Workbook.create();
  writeFixtureSheet(workbook, {
    ...baseAFixture,
    title: "",
  });
  return workbook;
}

function createMultiSheetBaseWorkbook(specification) {
  const workbook = Workbook.create();
  for (const sheetSpec of specification.sheets) {
    writeFixtureSheet(workbook, {
      sheetName: sheetSpec.sheetName,
      title: "",
      headerRow: specification.headerRow,
      header: specification.header,
      rows: sheetSpec.rows,
    });
  }
  return workbook;
}

function writeReportSheet(workbook, name, title, headers, rows, widths) {
  const sheet = workbook.worksheets.add(name);
  const columnCount = headers.length;
  const endColumn = columnName(columnCount);
  styleTitle(sheet, columnCount, title);
  sheet.getRangeByIndexes(1, 0, 1, columnCount).values = [headers];
  styleHeader(sheet.getRange(`A2:${endColumn}2`));
  if (rows.length) {
    sheet.getRangeByIndexes(2, 0, rows.length, columnCount).values = rows;
    styleData(sheet.getRange(`A3:${endColumn}${rows.length + 2}`));
  }
  sheet.freezePanes.freezeRows(2);
  applyFixtureWidths(sheet, widths);
  return sheet;
}

function budgetMatrixRows() {
  const rows = [[
    "PRE-001",
    budgetFixture.fileName,
    budgetFixture.sheetName,
    1,
    "Integração",
    "Linha de título antes do cabeçalho",
    "Removida — Antes do cabeçalho",
    "Selecione o cabeçalho na linha 2",
  ]];
  for (const [index, entry] of budgetFixture.rows.entries()) {
    rows.push([
      entry.id,
      budgetFixture.fileName,
      budgetFixture.sheetName,
      budgetFixture.headerRow + 1 + index,
      "Integração",
      entry.rule,
      entry.expected,
      entry.row[9],
    ]);
  }
  return rows;
}

function baseMatrixRows() {
  const rows = [[
    "B-PRE-001",
    generalBaseFixture.fileName,
    generalBaseFixture.sheetName,
    1,
    "Linha de título antes do cabeçalho",
    "Removida — Antes do cabeçalho",
    "Fonte SINAPI; cabeçalho na linha 2",
  ]];
  for (const [index, row] of generalBaseFixture.rows.entries()) {
    const id = row[0];
    let expected = "Mantida";
    if (/^ALR/.test(id) || id === "BAS-006" || /^DUP-003/.test(id)) expected = "Mantida com alerta";
    if (/^B-REV/.test(id)) expected = "Removida";
    if (/^DUP-001/.test(id)) expected = "Consolidada com a ocorrência equivalente";
    if (/^DUP-002/.test(id)) expected = "Mantida como descrição distinta";
    rows.push([
      id,
      generalBaseFixture.fileName,
      generalBaseFixture.sheetName,
      generalBaseFixture.headerRow + 1 + index,
      row[5],
      expected,
      "Fonte SINAPI",
    ]);
  }
  for (const [index, row] of baseAFixture.rows.entries()) {
    rows.push([row[0], baseAFixture.fileName, baseAFixture.sheetName, index + 2, row[5], "Mantida", "Fonte SINAPI"]);
  }
  for (const sheetSpec of baseBFixture.sheets) {
    for (const [index, row] of sheetSpec.rows.entries()) {
      rows.push([row[0], baseBFixture.fileName, sheetSpec.sheetName, index + 2, row[5], "Mantida", `Fonte ${sheetSpec.sourceIdentifier}`]);
    }
  }
  for (const sheetSpec of conflictBaseFixture.sheets) {
    for (const [index, row] of sheetSpec.rows.entries()) {
      rows.push([row[0], conflictBaseFixture.fileName, sheetSpec.sheetName, index + 2, row[5], "Conflito bloqueante", "Fonte SINAPI; usar separadamente"]);
    }
  }
  return rows;
}

function createMatrixWorkbook() {
  const workbook = Workbook.create();
  writeReportSheet(
    workbook,
    "Resumo",
    "SICORP v4.1.0 — matriz compacta de testes",
    ["Elemento", "Valor", "Como usar", "Resultado esperado"],
    [
      ["Objetivo", "Validar regras críticas com arquivos pequenos", "Execute npm run regression:fixtures", "Falha automática em qualquer divergência"],
      ["Orçamento", budgetFixture.fileName, "Aba ORCAMENTO; cabeçalho linha 2; colunas B:I", "26 itens aceitos e 11 revisões"],
      ["Base geral", generalBaseFixture.fileName, "Aba BASE_GERAL; cabeçalho linha 2; colunas B:E; fonte SINAPI", "25 itens canônicos e 13 revisões"],
      ["Bases A/B", `${baseAFixture.fileName} + ${baseBFixture.fileName}`, "Adicionar A e as duas abas de B conforme README", "Consolidação, complementaridade e fonte ORSE"],
      ["Conflitos", conflictBaseFixture.fileName, "Usar isoladamente", "2 conflitos; comparação bloqueada"],
      ["Tolerância", "R$ 0,01", "Informar 0,01 no SICORP", "ORC-004 classificado como Igual"],
      ["Política de código", "Ignorar caixa e separadores", "Ativar as duas opções", "ORC-010 e ORC-016 encontrados"],
      ["Camadas", "Unitária + fixtures + real", "Rodar npm test, regression:fixtures e regression:real", "Cobertura rápida e confirmação com dados reais"],
    ],
    [21, 43, 56, 44],
  );
  writeReportSheet(
    workbook,
    "Casos Orçamento",
    "Casos do orçamento",
    ["Caso", "Arquivo", "Aba", "Linha", "Camada", "Regra exercitada", "Resultado esperado", "Observação"],
    budgetMatrixRows(),
    [14, 34, 18, 10, 13, 39, 39, 48],
  );
  writeReportSheet(
    workbook,
    "Casos Bases",
    "Casos das bases referenciais",
    ["Caso", "Arquivo", "Aba", "Linha", "Regra exercitada", "Tratamento esperado", "Configuração/nota"],
    baseMatrixRows(),
    [15, 39, 23, 10, 47, 36, 38],
  );
  writeReportSheet(
    workbook,
    "Cobertura",
    "Cobertura por camada",
    ["Regra", "Camada principal", "Arquivo/comando", "Situação"],
    coverageRows,
    [50, 22, 35, 73],
  );
  writeReportSheet(
    workbook,
    "Resultados Esperados",
    "Oráculo agregado da regressão",
    ["Grupo", "Métrica", "Valor esperado", "Observação"],
    [
      ["Orçamento", "Aceitos", 26, "ORC-001 a ORC-026"],
      ["Orçamento", "Revisados", 11, "Inclui a linha anterior ao cabeçalho"],
      ["Catálogo combinado", "Itens canônicos", 32, "Base geral + A + B/SINAPI + B/ORSE"],
      ["Catálogo combinado", "Ocorrências aceitas", 35, "Conta todas as origens consolidadas"],
      ["Catálogo combinado", "Preços indisponíveis", 5, "Itens mantidos com alerta"],
      ["Comparação", "Total", 26, "Um resultado por item aceito do orçamento"],
      ["Comparação", "Iguais", 20, "Inclui o caso dentro da tolerância"],
      ["Comparação", "Abaixo", 1, "ORC-002"],
      ["Comparação", "Acima", 1, "ORC-003"],
      ["Comparação", "Não encontrados exibidos", 4, "3 referências ausentes + 1 preço da base indisponível"],
      ["Financeiro", "Total com BDI", 7215.98, "Soma item a item com arredondamento monetário"],
      ["Exportação", "Linhas/colunas", "26 / 17", "Além do cabeçalho"],
      ["Base de conflitos", "Conflitos", 2, "1 de preço + 1 de unidade"],
    ],
    [25, 34, 20, 62],
  );
  return workbook;
}

async function inspectAndRender(workbook, outputStem) {
  const inspection = await workbook.inspect({
    kind: "workbook,sheet,table,formula",
    maxChars: 7000,
    tableMaxRows: 6,
    tableMaxCols: 10,
    tableMaxCellChars: 90,
  });
  console.log(`[inspect] ${outputStem}: ${String(inspection.ndjson ?? inspection).slice(0, 1800)}`);

  for (const worksheet of workbook.worksheets.items) {
    const preview = await workbook.render({
      sheetName: worksheet.name,
      autoCrop: "all",
      scale: 0.9,
      format: "png",
    });
    const safeName = worksheet.name.replace(/[^a-z0-9_-]+/gi, "_");
    await fs.writeFile(
      path.join(previewDirectory, `${outputStem}__${safeName}.png`),
      new Uint8Array(await preview.arrayBuffer()),
    );
  }
}

async function saveWorkbook(workbook, fileName) {
  const outputStem = fileName.replace(/\.xlsx$/i, "");
  await inspectAndRender(workbook, outputStem);
  const output = await SpreadsheetFile.exportXlsx(workbook);
  await output.save(path.join(fixtureDirectory, fileName));
  console.log(`[xlsx] ${fileName}`);
}

const workbooks = [
  [createMatrixWorkbook(), "00_MATRIZ_CASOS_TESTE_v4.1.0.xlsx"],
  [createBudgetWorkbook(), budgetFixture.fileName],
  [createGeneralBaseWorkbook(), generalBaseFixture.fileName],
  [createBaseAWorkbook(), baseAFixture.fileName],
  [createMultiSheetBaseWorkbook(baseBFixture), baseBFixture.fileName],
  [createMultiSheetBaseWorkbook(conflictBaseFixture), conflictBaseFixture.fileName],
];

for (const [workbook, fileName] of workbooks) {
  await saveWorkbook(workbook, fileName);
}

console.log(`Test kit gerado em ${fixtureDirectory}`);
