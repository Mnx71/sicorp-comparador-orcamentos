# SICORP v4.1.0 — test kit compacto

Este conjunto reduz as planilhas reais a casos pequenos, identificáveis e reproduzíveis. Ele complementa os 79 testes unitários e a regressão com os arquivos reais; não substitui nenhuma dessas camadas.

## Arquivos

| Arquivo | Finalidade |
|---|---|
| `00_MATRIZ_CASOS_TESTE_v4.1.0.xlsx` | Índice dos casos, cobertura e resultados esperados. |
| `01_ORCAMENTO_CASOS_GERAIS.xlsx` | Orçamento com 26 itens aceitos e linhas deliberadamente rejeitadas. |
| `02_BASE_CASOS_GERAIS.xlsx` | Base principal com correspondências, preços indisponíveis, linhas estruturais e duplicidades. |
| `03_BASE_PRIORIDADE_A.xlsx` | Primeira base complementar para duplicidade equivalente e itens exclusivos. |
| `04_BASE_PRIORIDADE_B.xlsx` | Segunda base complementar, com abas SINAPI e ORSE. |
| `05_BASE_CONFLITOS_BLOQUEANTES.xlsx` | Base negativa: divergências de preço e unidade que devem bloquear a comparação. |
| `expected-results.json` | Oráculo independente usado pela regressão automatizada. |

Os nomes A/B foram preservados para facilitar o uso sequencial, mas a v4.1 não deve resolver silenciosamente preços divergentes por “prioridade”. Ocorrências equivalentes são consolidadas; preço ou unidade divergente para a mesma fonte, código e descrição gera conflito bloqueante.

## Execução automatizada

Na raiz do código-fonte da v4.1:

```bash
npm run regression:fixtures
```

O comando lê os cinco arquivos pelo mesmo leitor XLSX usado pelo SICORP, executa orçamento, catálogo, comparação, totais, Curva ABC, exportação e conflitos, e falha se qualquer resultado divergir de `expected-results.json`.

Para executar todas as camadas:

```bash
npm test
npm run regression:fixtures
npm run regression:real
```

Resultado esperado do teste compacto:

- orçamento: 26 aceitos e 11 revisados;
- catálogo combinado: 32 itens canônicos, 35 ocorrências e 13 revisões;
- comparação: 20 iguais, 1 abaixo, 1 acima e 4 exibidos como “Não encontrado”;
- divisão interna dos 4 “Não encontrados”: 3 referências ausentes e 1 preço da base indisponível;
- total com BDI: R$ 7.215,98;
- exportação: 26 linhas, 18 colunas e `styles.xml` válido;
- base negativa: 2 conflitos bloqueantes.

## Teste manual no SICORP

### 1. Orçamento

Carregue `01_ORCAMENTO_CASOS_GERAIS.xlsx`:

- aba: `ORCAMENTO`;
- cabeçalho: linha 2;
- Código: coluna B;
- Base/Referência: coluna C;
- Descrição: coluna D;
- Unidade: coluna E;
- Quantidade: coluna F;
- Preço sem BDI: coluna G;
- BDI: coluna H;
- Preço com BDI: coluna I.

### 2. Bases válidas

Adicione as configurações abaixo. A coluna A contém apenas o identificador do caso e deve ficar fora do mapeamento.

| Arquivo | Aba | Fonte | Cabeçalho | Código | Descrição | Unidade | Preço |
|---|---|---:|---:|---:|---:|---:|---:|
| `02_BASE_CASOS_GERAIS.xlsx` | `BASE_GERAL` | SINAPI | 2 | B | C | D | E |
| `03_BASE_PRIORIDADE_A.xlsx` | `BASE_A` | SINAPI | 1 | B | C | D | E |
| `04_BASE_PRIORIDADE_B.xlsx` | `SINAPI_EQUIVALENTES` | SINAPI | 1 | B | C | D | E |
| `04_BASE_PRIORIDADE_B.xlsx` | `ORSE` | ORSE | 1 | B | C | D | E |

Use tolerância de `0,01`, ative a comparação de códigos sem diferenciar maiúsculas/minúsculas e ative a remoção de separadores.

### 3. Resultado manual esperado

- 26 resultados;
- 20 iguais;
- 1 abaixo;
- 1 acima;
- 4 não encontrados;
- exportação CSV e XLSX com 26 linhas de dados.

O item `ORC-026` testa a normalização da fonte acentuada `SÍNAPI` para a chave `sinapi`.

### 4. Conflitos bloqueantes

Faça um teste separado com `05_BASE_CONFLITOS_BLOQUEANTES.xlsx`:

| Aba | Fonte | Cabeçalho | Código | Descrição | Unidade | Preço |
|---|---:|---:|---:|---:|---:|---:|
| `CONFLITO_PRECO` | SINAPI | 1 | B | C | D | E |
| `CONFLITO_UNIDADE` | SINAPI | 1 | B | C | D | E |

A preparação deve apontar dois conflitos e a comparação deve ser impedida até a correção ou remoção das ocorrências divergentes.

## Limites intencionais

Dois cenários continuam cobertos apenas por teste unitário:

- preço do orçamento indisponível na comparação: uma linha assim é rejeitada antes, durante a análise do orçamento;
- escolha da primeira ocorrência com preço utilizável: após a auditoria canônica da v4.1, duas ocorrências da mesma fonte, código e descrição com disponibilidade/preço diferente formam conflito bloqueante.
- código armazenado em fórmula `HYPERLINK`: o leitor cobre esse formato em `tests/read-workbook-file.test.js`; a ferramenta usada para gerar os XLSX compactos não produz um cache válido para essa fórmula, então o caso não foi inserido artificialmente no arquivo.

Essas limitações estão registradas na aba `Cobertura` da matriz para evitar a criação de fixtures que contradigam as regras atuais.
