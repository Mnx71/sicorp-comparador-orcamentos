# Decisões arquiteturais para a transição

Estas decisões foram aceitas para orientar a v4.1. Elas só devem ser reabertas diante de evidência nova e com registro explícito do impacto.

## DA-001 — mudar de Work antes da reestruturação

Status: aceita

Decisão: encerrar o Work da linha v4.0.x com a v4.0.5 intacta e iniciar toda a reestruturação no novo Work.

Motivo: arquitetura e testes constituem um resultado distinto; a mudança agora evita transferir uma refatoração pela metade.

## DA-002 — separar fonte e distribuição

Status: aceita

Decisão: desenvolver em módulos testáveis e gerar um único HTML offline para distribuição.

Consequência: o monólito deixa de ser a fonte principal, mas continua sendo o formato do produto entregue.

## DA-003 — preferir poucos deep modules

Status: aceita

Decisão: concentrar complexidade coerente atrás de interfaces menores. Não criar microarquivos, wrappers ou getters sem valor de domínio.

Consequência: a estrutura exata será decidida por locality, leverage e seams públicos, não por contagem de arquivos.

## DA-004 — usar modelos canônicos

Status: aceita em conceito; detalhes pendentes

Decisão: XLS, XLSX e CSV convergem para um workbook canônico. Orçamento e bases convergem para modelos normalizados antes da auditoria e comparação.

Pendente: formatos, tipos e assinaturas devem ser confirmados no novo Work.

## DA-005 — testes por seams confirmados

Status: aceita

Decisão: nenhum teste novo deve ser acoplado a uma função privada ou a um seam não aprovado. O comportamento é observado por interfaces públicas.

Consequência: o primeiro turno do novo Work propõe seams; o usuário os confirma antes da escrita dos testes.

## DA-006 — separar caracterização de TDD

Status: aceita

Decisão: comportamento existente é protegido por caracterização e paridade. Funcionalidade nova usa RED → GREEN, uma fatia vertical por vez.

Consequência: não fabricar um RED para comportamento já existente nem escrever uma suíte horizontal antecipando todas as futuras implementações.

## DA-007 — planilhas reais fora do ciclo normal

Status: aceita

Decisão: a suíte rápida usa objetos e matrizes; arquivos sintéticos pequenos validam adapters; arquivos reais ficam para regressão, desempenho e release.

Motivo: diagnóstico mais preciso, execução mais rápida e menor uso de contexto e I/O.

## DA-008 — fronteiras das funcionalidades futuras

Status: aceita em conceito

Decisão:

- auditoria completa consome o modelo de orçamento;
- central de bases produz catálogo canônico por adapters de provedor;
- conversor ORSE produz catálogo canônico e permanece especializado;
- o fluxo manual offline não depende da central.

Pendente: requisitos e seams detalhados serão tratados apenas quando cada funcionalidade entrar no roadmap ativo.

