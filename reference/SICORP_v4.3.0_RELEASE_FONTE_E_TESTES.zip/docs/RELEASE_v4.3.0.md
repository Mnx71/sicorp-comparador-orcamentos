# SICORP v4.3.0

## Leitor ORSE integrado

- aceita arquivos `.ORSE` diretamente na área de bases;
- converte e baixa automaticamente `nome_original_ORSE.xlsx`;
- gera as abas `Resumo`, `Insumos` e `Servicos` com a formatação do Conversor
  ORSE Excel v1.3.0;
- oferece internamente somente `Insumos` e `Servicos` para associação;
- mantém ativos com preço vazio e exclui registros inativos conforme as regras
  homologadas do conversor.

## Central de Bases

- catálogo padrão com 20 bases federais, estaduais e do Distrito Federal;
- `DER-ES_Edif` aponta para o referencial de edificações;
- `DER-ES_Rodo` aponta para o referencial de rodovias;
- toda correspondência aparece como **Sugestão para “X”**, em azul;
- o aviso **Não identificadas automaticamente:** também usa apresentação azul
  e largura ajustada ao conteúdo;
- **Ver outras (0)** permanece acessível quando todas as bases já estão
  identificadas, permitindo abrir o card **+**;
- confirmações desaparecem após aproximadamente três segundos e são removidas
  quando o contexto muda.

## Identificação dinâmica

- usa somente a sigla atual de cada card, sem aliases nem nome do órgão;
- ignora caixa, acentos e sinais separadores;
- pesquisa genérica por prefixo: `DER` sugere todos os DERs e `DER-ES` sugere
  `DER-ES_Edif` e `DER-ES_Rodo`;
- pesquisa específica mantém somente o card correspondente;
- aceita complementos de estado ou ano, como `CAESB-DF`, `CAESB-2026` e
  `DER-ES_Edif-2026`;
- cards renomeados, novos ou importados recebem automaticamente as mesmas
  regras, sem conservar identificadores antigos.

## Portabilidade e navegação

- JSON legível contendo somente `sigla`, `orgao` e `link`;
- IDs técnicos criados e mantidos internamente;
- siglas duplicadas bloqueadas;
- qualquer base pode ser excluída e a restauração é global;
- botões de navegação permanecem acionáveis e exibem uma janela explicativa
  quando existe impedimento.

## Validação

- 105 testes rápidos;
- regressão compacta com 26 resultados;
- regressão real com 424 resultados e 18 colunas de exportação;
- conversão real com 8.087 insumos e 9.931 serviços;
- baseline v4.0.5 preservada.

## Artefato

`dist/sicorp_comparador_orcamento_v4.3.0.html`

SHA-256: `adfb2a21629fc5c342c8f95d470068f613e83f5bd78bc7ea2bd255930c10afd4`.
