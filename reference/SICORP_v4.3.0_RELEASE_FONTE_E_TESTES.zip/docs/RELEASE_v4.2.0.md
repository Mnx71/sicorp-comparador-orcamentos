# SICORP v4.2.0

## Estado

Release final da linha v4.2, promovida em 26 de agosto de 2026.

## Alterações finais

- removido da página do orçamento o painel visível **Identificadores de fonte
  encontrados**; a identificação interna foi preservada para sugerir as bases
  automaticamente;
- atualizado o órgão da AGESUL para **Agência Estadual de Gestão de
  Empreendimentos de MS**;
- incluída a coluna **Quantidade** entre **BDI** e **Valor total com BDI** na
  tabela de resultados, no CSV, no XLSX e no texto copiado;
- mantidas todas as melhorias aprovadas nos candidatos anteriores da Central de
  Bases, pré-visualizações, persistência local e JSON portátil.

## Validação

- 92 testes automatizados aprovados;
- build e JavaScript inline validados contra a baseline imutável v4.0.5;
- regressão compacta: 26 resultados e exportação com 18 colunas;
- regressão real: 424 resultados e exportação com 18 colunas;
- totais financeiros preservados em R$ 1.990.067,16, com a diferença conhecida
  de R$ 0,02 causada pelo arredondamento hierárquico da planilha original;
- XLSX gerado pelo núcleo extraído do HTML final validado com 18 colunas, tipos
  numéricos, cores e formato monetário preservados;
- a automação de navegador permanece disponível em `npm run qa:browser`, mas
  requer que o Chromium do Playwright esteja instalado na máquina de execução.

## Artefato

`dist/sicorp_comparador_orcamento_v4.2.0.html`

SHA-256:

`75d71b3121b3924dfe33466c3581557a689e9ddce1af939db7449d2d6b47cff2`
