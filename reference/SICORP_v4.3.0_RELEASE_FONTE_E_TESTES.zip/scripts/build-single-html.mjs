import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import {
  consolidateSingleHtml,
  insertBeforeUniqueAnchor,
} from "../src/build/consolidate-single-html.js";
import { integratePriceSourceCentralHtml } from "../src/build/integrate-price-source-central-html.js";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const baselinePath = resolve(
  projectRoot,
  "baseline/sicorp_comparador_orcamento_v4.0.5.html",
);
const coreModules = [
  {
    path: resolve(projectRoot, "src/core/convert-orse-file.js"),
    exportNames: [
      "buildOrseDataset",
      "prepareOrseWorkbooks",
      "convertOrseFile",
      "writeOrseWorkbookXlsx",
    ],
  },
  {
    path: resolve(projectRoot, "src/core/read-workbook-file.js"),
    exportNames: ["readWorkbookFile"],
  },
  { path: resolve(projectRoot, "src/core/analyze-budget.js"), exportNames: ["analyzeBudget"] },
  {
    path: resolve(projectRoot, "src/core/prepare-reference-catalog.js"),
    exportNames: ["prepareReferenceCatalog"],
  },
  {
    path: resolve(projectRoot, "src/core/compare-budget-to-catalog.js"),
    exportNames: ["compareBudgetToCatalog"],
  },
  {
    path: resolve(projectRoot, "src/core/adapt-comparison-to-legacy-view.js"),
    exportNames: ["adaptComparisonToLegacyView"],
  },
  {
    path: resolve(projectRoot, "src/core/run-comparison-from-legacy-state.js"),
    exportNames: ["runComparisonFromLegacyState"],
  },
  {
    path: resolve(projectRoot, "src/core/prepare-comparison-export.js"),
    exportNames: ["prepareComparisonExport"],
  },
  {
    path: resolve(projectRoot, "src/core/create-price-source-central.js"),
    exportNames: ["createPriceSourceCentral"],
  },
];
const priceSourceUiModule = {
  path: resolve(projectRoot, "src/ui/install-price-source-central-ui.js"),
  exportName: "installPriceSourceCentralUi",
};
const distDirectory = resolve(projectRoot, "dist");
const distPath = resolve(
  distDirectory,
  "sicorp_comparador_orcamento_v4.3.0.html",
);

const appScriptAnchor = '  <script>\n    "use strict";';
const coreStartMarker = "  <!-- SICORP_V42_CORE_START -->";
const coreEndMarker = "  <!-- SICORP_V42_CORE_END -->";
const uiStartMarker = "  <!-- SICORP_V42_PRICE_SOURCE_RUNTIME_START -->";
const uiEndMarker = "  <!-- SICORP_V42_PRICE_SOURCE_RUNTIME_END -->";
const integrationStartMarker = "    /* SICORP_V41_INTEGRATION_START */";
const integrationEndMarker = "    /* SICORP_V41_INTEGRATION_END */";
const exportIntegrationStartMarker = "    /* SICORP_V41_EXPORT_INTEGRATION_START */";
const exportIntegrationEndMarker = "    /* SICORP_V41_EXPORT_INTEGRATION_END */";
const readerIntegrationStartMarker = "    /* SICORP_V41_READER_INTEGRATION_START */";
const readerIntegrationEndMarker = "    /* SICORP_V41_READER_INTEGRATION_END */";

function sha256(content) {
  return createHash("sha256").update(content).digest("hex");
}

function browserCoreSource(modules) {
  const converted = modules.map(({ source, exportNames }) => {
    let browserSource = source;
    for (const exportName of exportNames) {
      let convertedSource = browserSource.replace(
        `export function ${exportName}`,
        `function ${exportName}`,
      );
      if (convertedSource === browserSource) {
        convertedSource = browserSource.replace(
          `export async function ${exportName}`,
          `async function ${exportName}`,
        );
      }
      if (convertedSource === browserSource) {
        throw new Error(`O export público ${exportName} não foi encontrado.`);
      }
      browserSource = convertedSource;
    }
    return browserSource;
  }).join("\n\n");
  const publicFunctions = modules.flatMap(({ exportNames }) => exportNames);

  return [
    coreStartMarker,
    '  <script id="sicorpV42Core">',
    "    (() => {",
    '      "use strict";',
    converted
      .split("\n")
      .map((line) => `      ${line}`)
      .join("\n"),
    "      globalThis.SicorpCore = Object.freeze({",
    "        ...(globalThis.SicorpCore || {}),",
    ...publicFunctions.map((exportName) => `        ${exportName},`),
    "      });",
    "    })();",
    "  </script>",
    coreEndMarker,
    "",
  ].join("\n");
}

function browserPriceSourceUiSource(module) {
  const browserSource = module.source.replace(
    `export function ${module.exportName}`,
    `function ${module.exportName}`,
  );
  if (browserSource === module.source) {
    throw new Error(`O export público ${module.exportName} não foi encontrado.`);
  }
  return [
    uiStartMarker,
    '  <script id="sicorpV42PriceSourceUi">',
    "    (() => {",
    '      "use strict";',
    browserSource
      .split("\n")
      .map((line) => `      ${line}`)
      .join("\n"),
    "      globalThis.SicorpPriceSourceUi = Object.freeze({",
    `        ${module.exportName},`,
    "      });",
    "    })();",
    "  </script>",
    uiEndMarker,
    "",
  ].join("\n");
}

function browserIntegrationSource() {
  return [
    integrationStartMarker,
    "    function compare() {",
    "      try {",
    "        clearError();",
    "        if (!state.projectWorkbook) throw new Error(\"Carregue a planilha do projeto.\");",
    "        if (!state.bases.length) throw new Error(\"Adicione pelo menos uma base referencial.\");",
    "        const projectSheetName = el(\"projectSheet\").value;",
    "        const itemMapping = projectItemMapping();",
    "        const priceMapping = projectPriceMapping();",
    "        if (!itemMapping.valid) throw new Error(\"Selecione as colunas Código, Descrição, Unidade, Quantidade e Fonte do orçamento.\");",
    "        if (!priceMapping.valid) throw new Error(\"Selecione Preço sem BDI ou a combinação BDI (%) e Preço com BDI.\");",
    "        const execution = globalThis.SicorpCore.runComparisonFromLegacyState({",
    "          projectWorkbook: state.projectWorkbook,",
    "          projectSheetName,",
    "          projectHeaderRow: Math.max(1, Number(el(\"projectHeaderRow\").value || 1)),",
    "          projectMapping: {",
    "            code: itemMapping.codeCol,",
    "            source: itemMapping.sourceCol,",
    "            description: itemMapping.descriptionCol,",
    "            unit: itemMapping.unitCol,",
    "            quantity: itemMapping.quantityCol,",
    "            priceWithoutBdi: priceMapping.withoutBdiCol,",
    "            bdi: priceMapping.bdiCol,",
    "            priceWithBdi: priceMapping.withBdiCol,",
    "          },",
    "          bases: state.bases,",
    "          tolerance: Math.max(0, Number(el(\"tolerance\").value || 0)),",
    "          codePolicy: {",
    "            caseInsensitive: el(\"caseInsensitive\").checked,",
    "            stripSeparators: el(\"normalizeCodes\").checked,",
    "          },",
    "        });",
    "        state.results = execution.view.results;",
    "        state.resultSort = execution.view.defaultSort;",
    "        renderResults();",
    "        refreshWizardState();",
    "      } catch (err) { showError(err); }",
    "    }",
    integrationEndMarker,
    "",
  ].join("\n");
}

function browserExportIntegrationSource() {
  return [
    exportIntegrationStartMarker,
    "    function preparedVisibleExport() {",
    "      return globalThis.SicorpCore.prepareComparisonExport({",
    "        results: filteredResults(),",
    "        projectFileName: state.projectWorkbook?.fileName || \"orcamento\",",
    "      });",
    "    }",
    "",
    "    function exportCsv() {",
    "      const prepared = preparedVisibleExport();",
    "      if (!prepared.hasRows) return;",
    "      downloadBlob(prepared.csv.text, prepared.csv.mime, prepared.csv.filename);",
    "    }",
    "",
    "    function exportXlsx() {",
    "      const prepared = preparedVisibleExport();",
    "      if (!prepared.hasRows) return;",
    "      downloadBlob(prepared.xlsx.bytes, prepared.xlsx.mime, prepared.xlsx.filename);",
    "    }",
    "",
    "    async function copyTable() {",
    "      const prepared = preparedVisibleExport();",
    "      if (!prepared.hasRows) return;",
    "      await navigator.clipboard.writeText(prepared.clipboardText);",
    "      alert(\"Tabela copiada para a área de transferência.\");",
    "    }",
    exportIntegrationEndMarker,
    "",
  ].join("\n");
}

function browserReaderIntegrationSource() {
  return [
    readerIntegrationStartMarker,
    "    function updateOrseLoadingStage(fileName, stage, fraction, detail = null) {",
    "      const percent = Math.max(0, Math.min(100, Math.round((Number(fraction) || 0) * 100)));",
    "      const titles = {",
    "        decrypt: \"Decodificando arquivo ORSE…\",",
    "        extract: \"Extraindo tabelas do ORSE…\",",
    "        parse: \"Preparando insumos e serviços…\",",
    "        done: \"Gerando a planilha Excel…\",",
    "      };",
    "      const table = detail?.name ? ` · ${detail.name}` : \"\";",
    "      setLoading(true, titles[stage] || \"Convertendo arquivo ORSE…\", `${fileName} · ${percent}%${table}`);",
    "    }",
    "",
    "    async function loadWorkbook(file) {",
    "      const buffer = await readFileAsArrayBuffer(file);",
    "      const isOrse = /\\.orse$/i.test(file.name || \"\");",
    "      const binary = /\\.xlsx?$/i.test(file.name || \"\") || isOrse;",
    "      const spreadsheetRuntime = binary ? await ensureLegacyXlsReader() : undefined;",
    "      if (isOrse) {",
    "        const converted = await globalThis.SicorpCore.convertOrseFile({",
    "          fileName: file.name,",
    "          bytes: buffer,",
    "          onStage: (stage, fraction, detail) => updateOrseLoadingStage(file.name, stage, fraction, detail),",
    "        });",
    "        const xlsxBytes = globalThis.SicorpCore.writeOrseWorkbookXlsx(",
    "          converted.exportWorkbook,",
    "          spreadsheetRuntime,",
    "        );",
    "        downloadBlob(",
    "          xlsxBytes,",
    "          \"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\",",
    "          converted.outputFileName,",
    "        );",
    "        return converted.workbook;",
    "      }",
    "      return globalThis.SicorpCore.readWorkbookFile({",
    "        fileName: file.name,",
    "        bytes: buffer,",
    "      }, { spreadsheetRuntime });",
    "    }",
    readerIntegrationEndMarker,
    "",
  ].join("\n");
}

const [baseline, uiModuleSource, ...moduleSources] = await Promise.all([
  readFile(baselinePath, "utf8"),
  readFile(priceSourceUiModule.path, "utf8"),
  ...coreModules.map(({ path }) => readFile(path, "utf8")),
]);

if (!baseline.includes(appScriptAnchor)) {
  throw new Error("Âncora do script principal não encontrada na baseline.");
}

const coreBlock = browserCoreSource(
  coreModules.map((module, index) => ({ ...module, source: moduleSources[index] })),
);
const priceSourceUiBlock = browserPriceSourceUiSource({
  ...priceSourceUiModule,
  source: uiModuleSource,
});
const integrationBlock = browserIntegrationSource();
const exportIntegrationBlock = browserExportIntegrationSource();
const readerIntegrationBlock = browserReaderIntegrationSource();
const comparisonBaseline = consolidateSingleHtml(baseline, {
  readerIntegration: readerIntegrationBlock,
  comparisonIntegration: integrationBlock,
  exportIntegration: exportIntegrationBlock,
});
const integratedBaseline = integratePriceSourceCentralHtml(comparisonBaseline);
const output = insertBeforeUniqueAnchor(
  integratedBaseline,
  appScriptAnchor,
  `${coreBlock}${priceSourceUiBlock}`,
);

await mkdir(distDirectory, { recursive: true });
await writeFile(distPath, output, "utf8");
await writeFile(
  resolve(distDirectory, "SHA256SUMS.txt"),
  `${sha256(output)}  ${distPath.split("/").at(-1)}\n`,
  "utf8",
);

console.log(`HTML gerado: ${distPath}`);
console.log(`SHA-256: ${sha256(output)}`);
