import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const htmlPath = resolve(
  projectRoot,
  "dist/sicorp_comparador_orcamento_v4.3.0.html",
);
const outputDirectory = resolve(projectRoot, "qa/v4.3.0/built-export");

function extractStoredZipFile(bytes, expectedName) {
  const decoder = new TextDecoder();
  let offset = 0;
  while (offset + 30 <= bytes.length) {
    const view = new DataView(bytes.buffer, bytes.byteOffset + offset);
    if (view.getUint32(0, true) !== 0x04034b50) break;
    const size = view.getUint32(18, true);
    const nameLength = view.getUint16(26, true);
    const extraLength = view.getUint16(28, true);
    const nameStart = offset + 30;
    const dataStart = nameStart + nameLength + extraLength;
    const name = decoder.decode(bytes.subarray(nameStart, nameStart + nameLength));
    if (name === expectedName) {
      return decoder.decode(bytes.subarray(dataStart, dataStart + size));
    }
    offset = dataStart + size;
  }
  throw new Error(`Arquivo ${expectedName} não encontrado no ZIP.`);
}

const html = await readFile(htmlPath, "utf8");
const coreScripts = [...html.matchAll(
  /<script id="sicorpV42Core">([\s\S]*?)<\/script>/gi,
)];
assert.equal(coreScripts.length, 1, "O HTML deve conter um único núcleo canônico.");

const context = vm.createContext({
  ArrayBuffer,
  DataView,
  TextDecoder,
  TextEncoder,
  Uint8Array,
});
vm.runInContext(coreScripts[0][1], context, { filename: "sicorp-v4.3-core.js" });

const prepared = context.SicorpCore.prepareComparisonExport({
  projectFileName: "qa-html-gerado.xlsx",
  generatedAt: new Date("2026-08-21T12:00:00-03:00"),
  results: [{
    statusKey: "igual",
    status: "Igual",
    projectRow: 2,
    code: "001",
    projectSource: "SINAPI",
    projectDescription: "Item de validação",
    projectUnit: "un",
    projectValueRaw: "100,00",
    projectValue: 100,
    projectBdiRaw: "10%",
    projectBdiRate: 0.1,
    projectQuantityRaw: "1",
    projectQuantity: 1,
    projectTotalWithBdi: 110,
    projectTotalShare: 1,
    baseRow: "base.xlsx / PREÇOS, linha 2",
    baseDescription: "Item de validação",
    baseUnit: "un",
    baseValueRaw: "100,00",
    baseValue: 100,
    difference: 0,
    percentDifference: 0,
    baseName: "SINAPI teste",
  }],
});

const styles = extractStoredZipFile(prepared.xlsx.bytes, "xl/styles.xml");
const worksheet = extractStoredZipFile(prepared.xlsx.bytes, "xl/worksheets/sheet1.xml");
assert.match(
  styles,
  /formatCode="&quot;R\$&quot; #,##0\.00;\[Red\]-&quot;R\$&quot; #,##0\.00"/,
);
assert.doesNotMatch(styles, /<script>/i);
assert.match(worksheet, /<dimension ref="A1:R2"\/>/);
assert.match(worksheet, /<c r="I2" s="13"><v>1<\/v><\/c>/);

await mkdir(outputDirectory, { recursive: true });
const xlsxPath = resolve(outputDirectory, prepared.xlsx.filename);
await writeFile(xlsxPath, prepared.xlsx.bytes);

console.log(JSON.stringify({
  htmlPath,
  xlsxPath,
  stylesXmlValid: true,
  currencyFormatPreserved: true,
}, null, 2));
