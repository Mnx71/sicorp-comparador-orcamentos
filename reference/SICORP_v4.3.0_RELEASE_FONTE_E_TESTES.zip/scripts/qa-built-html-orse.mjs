import assert from "node:assert/strict";
import { gunzipSync, inflateSync } from "node:zlib";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const htmlPath = resolve(projectRoot, "dist/sicorp_comparador_orcamento_v4.3.0.html");
const sourcePath = resolve(projectRoot, "../project_sources/07-20260601-00.ORSE");
const baselinePath = resolve(projectRoot, "baseline/sicorp_comparador_orcamento_v4.0.5.html");

async function embeddedSheetJs() {
  const html = await readFile(baselinePath, "utf8");
  const match = html.match(/<script id="legacyXlsRuntime"[^>]*>([A-Za-z0-9+/=]+)<\/script>/);
  if (!match) throw new Error("Runtime XLS legado não encontrado na baseline.");
  const source = gunzipSync(Buffer.from(match[1], "base64")).toString("utf8");
  const context = {
    console, setTimeout, clearTimeout, ArrayBuffer, DataView,
    Uint8Array, Int8Array, Uint16Array, Int16Array, Uint32Array, Int32Array,
    Float32Array, Float64Array, Date, Math, JSON, TextDecoder, TextEncoder,
  };
  context.window = context;
  context.self = context;
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(source, context, { filename: "sheetjs-0.18.5.js" });
  return context.XLSX;
}

const [html, sourceBytes, spreadsheetRuntime] = await Promise.all([
  readFile(htmlPath, "utf8"),
  readFile(sourcePath),
  embeddedSheetJs(),
]);
const coreScripts = [...html.matchAll(/<script id="sicorpV42Core">([\s\S]*?)<\/script>/gi)];
assert.equal(coreScripts.length, 1, "O HTML deve conter um único núcleo canônico.");

const context = vm.createContext({
  console,
  setTimeout,
  clearTimeout,
  ArrayBuffer,
  DataView,
  Uint8Array,
  TextDecoder,
  TextEncoder,
  Intl,
  structuredClone,
});
vm.runInContext(coreScripts[0][1], context, { filename: "sicorp-v4.3-core.js" });

assert.equal(typeof context.SicorpCore.convertOrseFile, "function");
assert.equal(typeof context.SicorpCore.writeOrseWorkbookXlsx, "function");
const converted = await context.SicorpCore.convertOrseFile({
  fileName: "20260601-00.ORSE",
  bytes: new Uint8Array(sourceBytes),
}, {
  inflateZlib: (compressed) => new Uint8Array(inflateSync(compressed)),
  yieldControl: async () => {},
});
assert.equal(converted.data.stats.inputs.total, 8087);
assert.equal(converted.data.stats.services.total, 9931);
assert.equal(converted.outputFileName, "20260601-00_ORSE.xlsx");

const xlsxBytes = context.SicorpCore.writeOrseWorkbookXlsx(
  converted.exportWorkbook,
  spreadsheetRuntime,
);
assert.equal(xlsxBytes[0], 0x50);
assert.equal(xlsxBytes[1], 0x4b);
assert.ok(xlsxBytes.length > 1_000_000);

console.log(JSON.stringify({
  htmlPath,
  outputFileName: converted.outputFileName,
  inputs: converted.data.stats.inputs,
  services: converted.data.stats.services,
  xlsxBytes: xlsxBytes.length,
}, null, 2));
console.log("Núcleo ORSE extraído do HTML v4.3.0: aprovado");
