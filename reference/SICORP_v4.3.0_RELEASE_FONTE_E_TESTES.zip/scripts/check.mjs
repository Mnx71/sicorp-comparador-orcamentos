import { spawnSync } from "node:child_process";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function run(args) {
  const result = spawnSync(process.execPath, args, {
    cwd: projectRoot,
    stdio: "inherit",
  });

  if (result.status !== 0) process.exit(result.status ?? 1);
}

run(["--test"]);
run(["scripts/build-single-html.mjs"]);
run(["scripts/validate-build.mjs"]);

console.log("Release v4.3.0 validada com sucesso.");
