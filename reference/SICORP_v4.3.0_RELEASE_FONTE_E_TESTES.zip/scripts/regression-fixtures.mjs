import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { gunzipSync } from "node:zlib";

import { adaptComparisonToLegacyView } from "../src/core/adapt-comparison-to-legacy-view.js";
import { analyzeBudget } from "../src/core/analyze-budget.js";
import { compareBudgetToCatalog } from "../src/core/compare-budget-to-catalog.js";
import { prepareComparisonExport } from "../src/core/prepare-comparison-export.js";
import { prepareReferenceCatalog } from "../src/core/prepare-reference-catalog.js";
import { readWorkbookFile } from "../src/core/read-workbook-file.js";
import { runComparisonFromLegacyState } from "../src/core/run-comparison-from-legacy-state.js";

import {
  baseAFixture,
  baseBFixture,
  budgetFixture,
  conflictBaseFixture,
  generalBaseFixture,
} from "../testkit/fixture-spec.js";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const fixtureRoot = resolve(projectRoot, "testkit/fixtures");
const baselinePath = resolve(projectRoot, "baseline/sicorp_comparador_orcamento_v4.0.5.html");
const expected = JSON.parse(await readFile(
  resolve(projectRoot, "testkit/expected-results.json"),
  "utf8",
));

async function embeddedSheetJs() {
  const html = await readFile(baselinePath, "utf8");
  const match = html.match(/<script id="legacyXlsRuntime"[^>]*>([A-Za-z0-9+/=]+)<\/script>/);
  if (!match) throw new Error("Runtime XLS legado não encontrado na baseline.");
  const source = gunzipSync(Buffer.from(match[1], "base64")).toString("utf8");
  const context = {
    console,
    setTimeout,
    clearTimeout,
    ArrayBuffer,
    DataView,
    Uint8Array,
    Int8Array,
    Uint16Array,
    Int16Array,
    Uint32Array,
    Int32Array,
    Float32Array,
    Float64Array,
    Date,
    Math,
    JSON,
    TextDecoder,
    TextEncoder,
  };
  context.window = context;
  context.self = context;
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(source, context, { filename: "sheetjs-0.18.5.js" });
  if (!context.XLSX?.read || !context.XLSX?.utils) {
    throw new Error("Runtime XLS legado não foi inicializado.");
  }
  return context.XLSX;
}

async function loadWorkbook(xlsx, fileName) {
  const bytes = await readFile(resolve(fixtureRoot, fileName));
  return readWorkbookFile({ fileName, bytes }, { spreadsheetRuntime: xlsx });
}

function configuredBase({ id, specification, workbook, sheetName, sourceIdentifier, name }) {
  return {
    id,
    name,
    sourceIdentifier,
    sourceKey: sourceIdentifier.toLocaleLowerCase("pt-BR"),
    fileName: specification.fileName,
    workbook,
    sheetNames: [sheetName],
    headerRow: specification.headerRow,
    codeCol: specification.mapping.code,
    descCol: specification.mapping.description,
    unitCol: specification.mapping.unit,
    valueCol: specification.mapping.price,
  };
}

function canonicalBase(legacyBase) {
  return {
    name: legacyBase.name,
    source: legacyBase.sourceIdentifier,
    fileName: legacyBase.fileName,
    sheet: legacyBase.workbook.sheets.find((sheet) => sheet.name === legacyBase.sheetNames[0]),
    headerRowNumber: legacyBase.headerRow,
    mapping: {
      code: legacyBase.codeCol,
      description: legacyBase.descCol,
      unit: legacyBase.unitCol,
      price: legacyBase.valueCol,
    },
  };
}

function countsBy(rows, property) {
  return Object.fromEntries([...rows.reduce((counts, row) => {
    const key = row[property];
    counts.set(key, (counts.get(key) ?? 0) + 1);
    return counts;
  }, new Map()).entries()].sort(([left], [right]) => String(left).localeCompare(String(right), "pt-BR")));
}

function acceptedOccurrenceCount(catalog) {
  return catalog.items.reduce(
    (count, item) => count + Math.max(1, item.origins?.length ?? 0),
    0,
  );
}

function budgetCaseId(workbook, origin) {
  if (origin.rowNumber === 1) return "PRE-001";
  const sheet = workbook.sheets.find((candidate) => candidate.name === origin.sheet);
  return String(sheet?.rows?.[origin.rowNumber - 1]?.[0] ?? "").trim() || "PRE-001";
}

function catalogOriginKey(item) {
  return `${item.source}|${item.code}|${item.description}`;
}

function extractStoredZipFile(bytes, expectedName) {
  const decoder = new TextDecoder();
  let offset = 0;
  while (offset + 30 <= bytes.length) {
    const view = new DataView(bytes.buffer, bytes.byteOffset + offset);
    if (view.getUint32(0, true) !== 0x04034b50) break;
    const size = view.getUint32(18, true);
    const nameLength = view.getUint16(26, true);
    const extraLength = view.getUint16(28, true);
    const nameStart = offset + 30;
    const dataStart = nameStart + nameLength + extraLength;
    const name = decoder.decode(bytes.subarray(nameStart, nameStart + nameLength));
    if (name === expectedName) {
      return decoder.decode(bytes.subarray(dataStart, dataStart + size));
    }
    offset = dataStart + size;
  }
  throw new Error(`Arquivo ${expectedName} não encontrado no ZIP.`);
}

const xlsx = await embeddedSheetJs();
const [budgetWorkbook, generalWorkbook, baseAWorkbook, baseBWorkbook, conflictWorkbook] = await Promise.all([
  loadWorkbook(xlsx, budgetFixture.fileName),
  loadWorkbook(xlsx, generalBaseFixture.fileName),
  loadWorkbook(xlsx, baseAFixture.fileName),
  loadWorkbook(xlsx, baseBFixture.fileName),
  loadWorkbook(xlsx, conflictBaseFixture.fileName),
]);

for (const workbook of [budgetWorkbook, generalWorkbook, baseAWorkbook, baseBWorkbook, conflictWorkbook]) {
  assert.equal(workbook.format, "xlsx");
  assert.ok(workbook.sheets.length >= 1);
}

const bases = [
  configuredBase({
    id: 1,
    specification: generalBaseFixture,
    workbook: generalWorkbook,
    sheetName: generalBaseFixture.sheetName,
    sourceIdentifier: generalBaseFixture.sourceIdentifier,
    name: "SINAPI — casos gerais",
  }),
  configuredBase({
    id: 2,
    specification: baseAFixture,
    workbook: baseAWorkbook,
    sheetName: baseAFixture.sheetName,
    sourceIdentifier: baseAFixture.sourceIdentifier,
    name: "SINAPI — Base A",
  }),
  ...baseBFixture.sheets.map((sheet, index) => configuredBase({
    id: index + 3,
    specification: baseBFixture,
    workbook: baseBWorkbook,
    sheetName: sheet.sheetName,
    sourceIdentifier: sheet.sourceIdentifier,
    name: `${sheet.sourceIdentifier} — Base B`,
  })),
];

const codePolicy = {
  caseInsensitive: expected.configuration.caseInsensitiveCodes,
  stripSeparators: expected.configuration.stripCodeSeparators,
};
const dependencies = {
  analyzeBudget,
  prepareReferenceCatalog,
  compareBudgetToCatalog,
  adaptComparisonToLegacyView,
};

const execution = runComparisonFromLegacyState({
  projectWorkbook: budgetWorkbook,
  projectSheetName: budgetFixture.sheetName,
  projectHeaderRow: budgetFixture.headerRow,
  projectMapping: budgetFixture.mapping,
  bases,
  tolerance: expected.configuration.tolerance,
  codePolicy,
}, dependencies);

assert.equal(execution.budget.stats.accepted, expected.budget.accepted);
assert.equal(execution.budget.stats.reviewed, expected.budget.reviewed);
assert.deepEqual(countsBy(execution.budget.reviewRows, "reason"), expected.budget.reviewReasons);
assert.deepEqual(
  execution.budget.reviewRows.map((row) => budgetCaseId(budgetWorkbook, row.origin)).sort(),
  ["PRE-001", ...Array.from({ length: 10 }, (_, index) => `REV-${String(index + 1).padStart(3, "0")}`)].sort(),
);

assert.equal(execution.catalog.stats.accepted, expected.catalog.acceptedCanonicalItems);
assert.equal(acceptedOccurrenceCount(execution.catalog), expected.catalog.acceptedOccurrences);
assert.equal(execution.catalog.stats.reviewed, expected.catalog.reviewed);
assert.equal(execution.catalog.stats.unavailablePrices, expected.catalog.unavailablePrices);
assert.equal(execution.catalog.conflicts.length, expected.catalog.conflicts);
assert.deepEqual(countsBy(execution.catalog.reviewRows, "reason"), expected.catalog.reviewReasons);

for (const [key, originCount] of Object.entries(expected.catalog.originCounts)) {
  const item = execution.catalog.items.find((candidate) => catalogOriginKey(candidate) === key);
  assert.ok(item, `Item canônico não encontrado: ${key}`);
  assert.equal(item.origins.length, originCount, `Contagem de origens divergente: ${key}`);
}

const stats = execution.comparison.stats;
assert.equal(stats.total, expected.comparison.total);
assert.equal(stats.matched, expected.comparison.matched);
assert.equal(stats.compared, expected.comparison.compared);
assert.equal(stats.below, expected.comparison.below);
assert.equal(stats.equal, expected.comparison.equal);
assert.equal(stats.above, expected.comparison.above);
assert.equal(stats.notFound, expected.comparison.referenceNotFound);
assert.equal(stats.budgetPriceUnavailable, expected.comparison.budgetPriceUnavailable);
assert.equal(stats.basePriceUnavailable, expected.comparison.basePriceUnavailable);
assert.equal(
  execution.comparison.results.filter((result) => result.statusKey === "nao-encontrado").length,
  expected.comparison.displayedNotFound,
);
assert.equal(execution.comparison.financial.totalWithBdi, expected.comparison.totalWithBdi);
assert.equal(execution.comparison.financial.knownItemCount, expected.comparison.knownFinancialItems);
assert.equal(execution.comparison.curveAbc.length, expected.comparison.total);

for (const result of execution.comparison.results) {
  const caseId = budgetCaseId(budgetWorkbook, result.budgetItem.origin);
  const expectedResult = expected.comparison.caseResults[caseId];
  assert.ok(expectedResult, `Oráculo ausente para ${caseId}`);
  assert.deepEqual(
    [result.statusKey, result.availabilityKey],
    expectedResult,
    `Resultado divergente para ${caseId}`,
  );
}

const accentedSourceItem = execution.budget.items.find(
  (item) => budgetCaseId(budgetWorkbook, item.origin) === "ORC-026",
);
assert.equal(accentedSourceItem.codeRaw, "001.005");
assert.equal(accentedSourceItem.code, "1005");
assert.equal(accentedSourceItem.source, "SÍNAPI");
assert.equal(accentedSourceItem.sourceKey, "sinapi");

const preparedExport = prepareComparisonExport({
  results: execution.view.results,
  projectFileName: budgetFixture.fileName,
  generatedAt: new Date("2026-08-21T12:00:00-03:00"),
});
assert.equal(preparedExport.table.rows.length, expected.export.rows);
assert.equal(preparedExport.table.columns.length, expected.export.columns);
assert.equal(preparedExport.csv.text.split("\r\n").length, expected.export.csvLines);
assert.equal(String.fromCharCode(...preparedExport.xlsx.bytes.slice(0, 2)), expected.export.xlsxSignature);

const stylesXml = extractStoredZipFile(preparedExport.xlsx.bytes, "xl/styles.xml");
const sheetXml = extractStoredZipFile(preparedExport.xlsx.bytes, "xl/worksheets/sheet1.xml");
assert.match(stylesXml, /formatCode="&quot;R\$&quot; #,##0\.00;\[Red\]-&quot;R\$&quot; #,##0\.00"/);
assert.doesNotMatch(stylesXml, /formatCode="[^"]*</);
assert.doesNotMatch(stylesXml, /<script>/i);
assert.match(sheetXml, new RegExp(`<dimension ref="A1:R${expected.export.rows + 1}"/>`));

const conflictBases = conflictBaseFixture.sheets.map((sheet, index) => configuredBase({
  id: index + 100,
  specification: conflictBaseFixture,
  workbook: conflictWorkbook,
  sheetName: sheet.sheetName,
  sourceIdentifier: conflictBaseFixture.sourceIdentifier,
  name: `SINAPI — ${sheet.sheetName}`,
}));
const conflictCatalog = prepareReferenceCatalog({
  bases: conflictBases.map(canonicalBase),
  codePolicy,
});
assert.equal(conflictCatalog.stats.accepted, expected.conflictCatalog.acceptedCanonicalItems);
assert.equal(conflictCatalog.conflicts.length, expected.conflictCatalog.conflicts);
assert.deepEqual(
  countsBy(conflictCatalog.conflicts.flatMap((conflict) => conflict.reasons.map((reason) => ({ reason }))), "reason"),
  expected.conflictCatalog.reasons,
);
assert.throws(
  () => compareBudgetToCatalog({ budget: execution.budget, catalog: conflictCatalog, tolerance: 0.01 }),
  /duplicidades bloqueantes/i,
);

const formulaErrors = ["#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A"];
for (const workbook of [budgetWorkbook, generalWorkbook, baseAWorkbook, baseBWorkbook, conflictWorkbook]) {
  for (const sheet of workbook.sheets) {
    for (const row of sheet.rows) {
      for (const value of row) {
        assert.ok(!formulaErrors.includes(String(value)), `${workbook.fileName}/${sheet.name}: erro de fórmula ${value}`);
      }
    }
  }
}

const summary = {
  fixtures: {
    files: 5,
    sheets: [budgetWorkbook, generalWorkbook, baseAWorkbook, baseBWorkbook, conflictWorkbook]
      .reduce((total, workbook) => total + workbook.sheets.length, 0),
  },
  budget: execution.budget.stats,
  catalog: {
    canonicalItems: execution.catalog.stats.accepted,
    acceptedOccurrences: acceptedOccurrenceCount(execution.catalog),
    reviewed: execution.catalog.stats.reviewed,
    unavailablePrices: execution.catalog.stats.unavailablePrices,
  },
  comparison: {
    ...stats,
    displayedNotFound: expected.comparison.displayedNotFound,
    totalWithBdi: execution.comparison.financial.totalWithBdi,
  },
  export: {
    rows: preparedExport.table.rows.length,
    columns: preparedExport.table.columns.length,
    xlsxBytes: preparedExport.xlsx.bytes.length,
    stylesXmlValid: true,
  },
  conflicts: {
    total: conflictCatalog.conflicts.length,
    blocking: true,
  },
};

console.log(JSON.stringify(summary, null, 2));
console.log("Regressão por fixtures v4.1.0: aprovada");
