import { mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { prepareComparisonExport } from "../src/core/prepare-comparison-export.js";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const outputDirectory = resolve(projectRoot, "qa/v4.3.0/core-export");

function row({
  statusKey,
  status,
  projectRow,
  code,
  projectValue,
  baseValue,
}) {
  const quantity = 2;
  const withBdi = projectValue * 1.1;
  const total = quantity * withBdi;
  const difference = Number.isFinite(baseValue) ? projectValue - baseValue : Number.NaN;
  return {
    statusKey,
    status,
    projectRow,
    code,
    projectSource: "SINAPI",
    projectDescription: `Item ${code}`,
    projectUnit: "un",
    projectValueRaw: String(projectValue),
    projectValue,
    projectBdiRaw: "10%",
    projectBdiRate: 0.1,
    projectQuantityRaw: String(quantity),
    projectQuantity: quantity,
    projectTotalWithBdi: total,
    projectTotalShare: total / 990,
    baseRow: Number.isFinite(baseValue) ? `base.xlsx / PREÇOS, linha ${projectRow}` : "",
    baseDescription: Number.isFinite(baseValue) ? `Item ${code}` : "",
    baseUnit: Number.isFinite(baseValue) ? "un" : "",
    baseValueRaw: Number.isFinite(baseValue) ? String(baseValue) : "",
    baseValue,
    difference,
    percentDifference: Number.isFinite(difference) && baseValue !== 0
      ? difference / baseValue
      : Number.NaN,
    baseName: Number.isFinite(baseValue) ? "SINAPI teste" : "",
  };
}

const prepared = prepareComparisonExport({
  projectFileName: "orçamento-homologação.xlsx",
  generatedAt: new Date("2026-08-21T12:00:00-03:00"),
  results: [
    row({ statusKey: "acima", status: "Acima", projectRow: 2, code: "A-001", projectValue: 120, baseValue: 100 }),
    row({ statusKey: "igual", status: "Igual", projectRow: 3, code: "I-001", projectValue: 100, baseValue: 100 }),
    row({ statusKey: "abaixo", status: "Abaixo", projectRow: 4, code: "B-001", projectValue: 80, baseValue: 100 }),
    row({ statusKey: "nao-encontrado", status: "Não encontrado", projectRow: 5, code: "N-001", projectValue: 150, baseValue: Number.NaN }),
  ],
});

await mkdir(outputDirectory, { recursive: true });
const xlsxPath = resolve(outputDirectory, prepared.xlsx.filename);
const csvPath = resolve(outputDirectory, prepared.csv.filename);
await writeFile(xlsxPath, prepared.xlsx.bytes);
await writeFile(csvPath, prepared.csv.text, "utf8");

console.log(JSON.stringify({ xlsxPath, csvPath, rows: prepared.table.rows.length }, null, 2));
