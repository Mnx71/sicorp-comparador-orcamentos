const assert = require("node:assert/strict");
const { execFileSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

function playwrightRuntime() {
  try {
    return require("playwright");
  } catch (firstError) {
    const moduleRoot = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
    if (!moduleRoot) throw firstError;
    return require(path.join(moduleRoot, "playwright"));
  }
}

async function waitForEnabled(page, selector) {
  await page.locator(selector).waitFor({ state: "visible" });
  await page.waitForFunction(
    (target) => !document.querySelector(target)?.disabled,
    selector,
  );
}

async function mapColumns(page, mapping) {
  for (const [selector, value] of Object.entries(mapping)) {
    await page.selectOption(selector, String(value));
  }
}

(async () => {
  const projectRoot = path.resolve(__dirname, "..");
  const outputDirectory = path.resolve(projectRoot, "qa/v4.3.0");
  fs.mkdirSync(outputDirectory, { recursive: true });

  const htmlPath = path.resolve(
    projectRoot,
    "dist/sicorp_comparador_orcamento_v4.3.0.html",
  );
  const budgetPath = path.resolve(projectRoot, "tests/fixtures/browser-budget.csv");
  const basePath = path.resolve(projectRoot, "tests/fixtures/SINAPI-browser-base.csv");
  const orsePath = path.resolve(projectRoot, "../project_sources/07-20260601-00.ORSE");
  const { chromium } = playwrightRuntime();
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const pageErrors = [];
  page.on("pageerror", (error) => pageErrors.push(error.message));
  page.on("dialog", (dialog) => dialog.accept());
  await page.addInitScript(() => {
    localStorage.removeItem("sicorp.priceSourceCentral.v1");
    let copiedText = "";
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: {
        writeText: async (value) => { copiedText = String(value); },
        readText: async () => copiedText,
      },
    });
  });

  try {
    await page.goto(pathToFileURL(htmlPath).href);
    assert.equal(await page.locator("#baseFile").getAttribute("accept"), ".xlsx,.xls,.csv,.txt,.orse");
    assert.equal(await page.getByText("Planilhas XLSX, XLS, CSV, TXT ou ORSE").count(), 1);
    assert.equal(await page.getByText("Identificadores de fonte encontrados").count(), 0);
    const publishedFunctions = await page.evaluate(() => Object.keys(globalThis.SicorpCore || {}));
    assert.ok(publishedFunctions.includes("runComparisonFromLegacyState"));
    assert.ok(publishedFunctions.includes("prepareComparisonExport"));
    assert.ok(publishedFunctions.includes("createPriceSourceCentral"));
    const sourceMatches = await page.evaluate(() => {
      const central = globalThis.SicorpCore.createPriceSourceCentral();
      const renamed = globalThis.SicorpCore.createPriceSourceCentral();
      const derEs = renamed.records().find((record) => record.id === "der-es");
      renamed.save({ ...derEs, acronym: "teste" });
      const added = central.save({
        acronym: "NOVA-BASE",
        agency: "Órgão novo",
        url: "https://example.gov.br/nova-base",
      });
      return {
        genericDer: central.query({ budgetSources: ["DER"] }).items.map((item) => item.acronym),
        compactDer: central.query({ budgetSources: ["DERSP"] }).items.map((item) => item.acronym),
        derYear: central.query({ budgetSources: ["DER-ES-2026"] }).items.map((item) => item.acronym),
        caesbYear: central.query({ budgetSources: ["CAESB-2026"] }).items.map((item) => item.acronym),
        newBase: central.query({ budgetSources: ["NOVA-BASE-2026"] }).identifiedIds.includes(added.id),
        renamedOld: renamed.query({ budgetSources: ["DER-ES"] }).identifiedIds.includes("der-es"),
        renamedNew: renamed.query({ budgetSources: ["teste-2026"] }).identifiedIds.includes("der-es"),
        aliases: central.records().some((record) => Object.hasOwn(record, "aliases")),
        unknown: central.query({ budgetSources: ["DNIT"] }).unknownBudgetSources,
      };
    });
    assert.deepEqual(sourceMatches.genericDer, ["DER-ES_Edif", "DER-ES_Rodo", "DER-MG / SICOR", "DER-PB", "DER-PR", "DER-SP"]);
    assert.deepEqual(sourceMatches.compactDer, ["DER-SP"]);
    assert.deepEqual(sourceMatches.derYear, ["DER-ES_Edif", "DER-ES_Rodo"]);
    assert.deepEqual(sourceMatches.caesbYear, ["CAESB"]);
    assert.equal(sourceMatches.newBase, true);
    assert.equal(sourceMatches.renamedOld, false);
    assert.equal(sourceMatches.renamedNew, true);
    assert.equal(sourceMatches.aliases, false);
    assert.deepEqual(sourceMatches.unknown, ["DNIT"]);
    const entrypoints = await page.evaluate(() => ({
      loadWorkbook: typeof loadWorkbook,
      compare: typeof compare,
      exportCsv: typeof exportCsv,
      exportXlsx: typeof exportXlsx,
      copyTable: typeof copyTable,
      loadWorkbookLegacy: typeof globalThis.loadWorkbookLegacy,
      compareLegacy: typeof globalThis.compareLegacy,
      exportCsvLegacy: typeof globalThis.exportCsvLegacy,
      exportXlsxLegacy: typeof globalThis.exportXlsxLegacy,
      copyTableLegacy: typeof globalThis.copyTableLegacy,
    }));
    for (const name of ["loadWorkbook", "compare", "exportCsv", "exportXlsx", "copyTable"]) {
      assert.equal(entrypoints[name], "function");
      assert.equal(entrypoints[`${name}Legacy`], "undefined");
    }

    assert.equal(await page.locator("#projectNextBtn").isEnabled(), true);
    await page.click("#projectNextBtn");
    await page.locator("#blockingDialog[open]").waitFor();
    assert.match(await page.locator("#blockingDialogMessage").textContent(), /Carregue um arquivo de orçamento/);
    await page.click("#blockingDialogReturn");
    await page.waitForFunction(() => !document.querySelector("#blockingDialog")?.open);

    await page.setInputFiles("#projectFile", budgetPath);
    await page.locator("#projectConfigArea:not(.hidden)").waitFor();
    await mapColumns(page, {
      "#projectCodeCol": 0,
      "#projectSourceCol": 1,
      "#projectDescCol": 2,
      "#projectUnitCol": 3,
      "#projectQuantityCol": 4,
      "#projectWithoutBdiCol": 5,
      "#projectBdiCol": 6,
      "#projectWithBdiCol": 7,
    });
    await waitForEnabled(page, "#projectNextBtn");
    await page.click("#projectNextBtn");

    assert.equal(await page.locator("#basesNextBtn").isEnabled(), true);
    await page.click("#basesNextBtn");
    await page.locator("#blockingDialog[open]").waitFor();
    assert.match(await page.locator("#blockingDialogMessage").textContent(), /Adicione pelo menos uma base de preços/);
    await page.click("#blockingDialogReturn");

    const orseDownloadPromise = page.waitForEvent("download");
    await page.setInputFiles("#baseFile", orsePath);
    const orseDownload = await orseDownloadPromise;
    assert.equal(orseDownload.suggestedFilename(), "20260601-00_ORSE.xlsx");
    const convertedOrsePath = path.join(outputDirectory, orseDownload.suggestedFilename());
    await orseDownload.saveAs(convertedOrsePath);
    await page.locator("#baseConfigArea:not(.hidden)").waitFor();
    assert.deepEqual(
      await page.locator("#baseSheet option").evaluateAll((options) => options.map((option) => option.value)),
      ["Insumos", "Servicos"],
    );
    assert.equal(await page.locator("#baseSheet").inputValue(), "Insumos");
    assert.equal(await page.locator("#baseCodeCol").inputValue(), "0");
    assert.equal(await page.locator("#baseDescCol").inputValue(), "1");
    assert.equal(await page.locator("#baseUnitCol").inputValue(), "2");
    assert.equal(await page.locator("#baseValueCol").inputValue(), "3");
    assert.equal(await page.locator("#baseSourceIdentifier").inputValue(), "");

    await page.locator("#priceSourceLinks .price-source-link").waitFor();
    assert.equal(await page.locator("#priceSourceLinks .price-source-link").count(), 1);
    assert.equal(await page.locator("#priceSourceNew").count(), 0);
    assert.equal(await page.locator("#priceSourceLinks .price-source-link strong").textContent(), "SINAPI");
    assert.equal(await page.locator("#priceSourceLinks .price-source-match-badge").textContent(), "Sugestão para “SINAPI”");
    assert.equal(
      await page.locator("#priceSourceLinks .price-source-link").getAttribute("href"),
      "https://www.caixa.gov.br/poder-publico/modernizacao-gestao/sinapi/Paginas/default.aspx",
    );

    await page.click("#priceSourceShowAll");
    assert.equal(await page.locator("#priceSourceLinks .price-source-link").count(), 20);
    assert.equal(await page.locator("#priceSourceLinks .price-source-settings").count(), 20);
    assert.equal(await page.locator("#priceSourceRestore").count(), 0);
    assert.equal(
      await page.locator('[data-price-source-edit="agesul"]').locator("xpath=preceding-sibling::*[1]").textContent(),
      "AGESULAgência Estadual de Gestão de Empreendimentos de MS",
    );
    assert.equal(await page.locator("#priceSourceNew").count(), 1);
    const defaultAcronyms = await page.locator("#priceSourceLinks .price-source-link strong").allTextContents();
    assert.equal(defaultAcronyms.some((acronym) => ["SCO-RIO", "SIURB", "SUDECAP"].includes(acronym)), false);
    assert.equal(defaultAcronyms.includes("CASAN"), false);
    assert.equal(defaultAcronyms.includes("DER-PB"), true);
    assert.equal(defaultAcronyms.includes("SEOP-PA"), true);
    await page.fill("#priceSourceSearch", "saneamento parana");
    assert.equal(await page.locator("#priceSourceLinks .price-source-link").count(), 1);
    assert.equal(await page.locator("#priceSourceLinks .price-source-link strong").textContent(), "SANEPAR");
    await page.fill("#priceSourceSearch", "");

    await page.click('[data-price-source-edit="sinapi"]');
    await page.locator("#priceSourceEditorDialog[open]").waitFor();
    assert.equal(await page.locator("#priceSourceUrl").getAttribute("placeholder"), "https://");
    assert.equal(await page.locator("#priceSourceUrl").getAttribute("required"), "");
    await page.fill("#priceSourceUrl", "");
    await page.click("#priceSourceSave");
    assert.equal(await page.locator("#priceSourceEditorDialog").getAttribute("open"), "");
    assert.equal(await page.locator("#priceSourceUrl").evaluate((input) => input.validity.valueMissing), true);
    await page.fill("#priceSourceUrl", "example.gov.br/sinapi atualizado");
    await page.click("#priceSourceSave");
    assert.equal(await page.locator("#priceSourceStatus").textContent(), "Alterações salvas.");
    await page.waitForTimeout(3200);
    assert.equal(await page.locator("#priceSourceStatus").textContent(), "");
    const locallySaved = await page.evaluate(() => JSON.parse(localStorage.getItem("sicorp.priceSourceCentral.v1")));
    assert.equal(locallySaved.storageVersion, 1);
    assert.equal(locallySaved.overrides.find((record) => record.id === "sinapi").url, "example.gov.br/sinapi atualizado");

    await page.click('[data-price-source-edit="caesb"]');
    await page.locator("#priceSourceRemove:not(.hidden)").waitFor();
    await page.click("#priceSourceRemove");
    assert.equal(await page.locator("#priceSourceLinks .price-source-link").count(), 19);

    await page.click("#priceSourceNew");
    await page.fill("#priceSourceAcronym", "BASE-QA");
    await page.fill("#priceSourceAgency", "Órgão sintético de teste");
    await page.fill("#priceSourceUrl", "rede-interna/base-qa");
    await page.click("#priceSourceSave");
    assert.equal(await page.locator("#priceSourceLinks .price-source-link").count(), 20);
    const acronyms = await page.locator("#priceSourceLinks .price-source-link strong").allTextContents();
    assert.deepEqual(acronyms, [...acronyms].sort((a, b) => a.localeCompare(b, "pt-BR", {
      sensitivity: "base",
      numeric: true,
    })));

    const jsonDownloadPromise = page.waitForEvent("download");
    await page.click("#priceSourceExport");
    const jsonDownload = await jsonDownloadPromise;
    const jsonPath = path.join(outputDirectory, jsonDownload.suggestedFilename());
    await jsonDownload.saveAs(jsonPath);
    const portable = JSON.parse(fs.readFileSync(jsonPath, "utf8"));
    assert.equal(Object.hasOwn(portable, "versao"), false);
    assert.equal(portable.bases.length, 20);
    assert.equal(portable.bases.some((record) => Object.hasOwn(record, "id")), false);
    assert.equal(portable.bases.some((record) => record.sigla === "CAESB"), false);
    assert.equal(portable.bases.find((record) => record.sigla === "BASE-QA").link, "rede-interna/base-qa");

    await page.setInputFiles("#baseFile", basePath);
    await page.locator("#baseConfigArea:not(.hidden)").waitFor();
    await page.selectOption("#baseSourceIdentifier", { label: "SINAPI" });
    await mapColumns(page, {
      "#baseCodeCol": 0,
      "#baseDescCol": 1,
      "#baseUnitCol": 2,
      "#baseValueCol": 3,
    });
    await waitForEnabled(page, "#addBaseBtn");
    await page.click("#addBaseBtn");
    await page.locator("#baseListTable tbody tr").waitFor();
    await waitForEnabled(page, "#basesNextBtn");
    await page.click("#basesNextBtn");

    await waitForEnabled(page, "#compareBtn");
    await page.click("#compareBtn");
    await page.locator("#resultPanel:not(.hidden)").waitFor();
    assert.deepEqual(
      await page.locator("#resultTable thead th").evaluateAll((cells) => cells.map((cell) => cell.textContent.replace(/[↕▲▼]/g, "").trim()).slice(7, 10)),
      ["BDI", "Quantidade", "Valor total com BDI"],
    );
    const statuses = await page.locator("#resultTable tbody tr td:first-child").allTextContents();
    assert.deepEqual(statuses, ["Acima", "Abaixo"]);
    assert.equal(await page.locator("#mTotal").textContent(), "2");

    await page.fill("#searchText", "001.002");
    await page.waitForFunction(() => document.querySelectorAll("#resultTable tbody tr").length === 1);

    const csvDownloadPromise = page.waitForEvent("download");
    await page.click("#exportCsvBtn");
    const csvDownload = await csvDownloadPromise;
    const csvPath = path.join(outputDirectory, csvDownload.suggestedFilename());
    await csvDownload.saveAs(csvPath);

    const xlsxDownloadPromise = page.waitForEvent("download");
    await page.click("#exportXlsxBtn");
    const xlsxDownload = await xlsxDownloadPromise;
    const xlsxPath = path.join(outputDirectory, xlsxDownload.suggestedFilename());
    await xlsxDownload.saveAs(xlsxPath);

    await page.click("#copyTableBtn");
    const clipboard = await page.evaluate(() => navigator.clipboard.readText());
    assert.match(clipboard, /\nAbaixo\t2\t001\.002\tSINAPI/);
    assert.doesNotMatch(clipboard, /001\.001/);

    const csv = fs.readFileSync(csvPath, "utf8");
    assert.ok(csv.startsWith("\ufeff\"Status\";"));
    assert.match(csv, /"BDI";"Quantidade";"Valor total com BDI"/);
    assert.match(csv, /001\.002/);
    assert.doesNotMatch(csv, /001\.001/);
    assert.equal(csvDownload.suggestedFilename(), "sicorp_v4_comparacao_browser-budget.csv");
    assert.equal(xlsxDownload.suggestedFilename(), "sicorp_v4_comparacao_browser-budget.xlsx");
    execFileSync("unzip", ["-t", xlsxPath], { stdio: "ignore" });
    const worksheet = execFileSync(
      "unzip",
      ["-p", xlsxPath, "xl/worksheets/sheet1.xml"],
      { encoding: "utf8" },
    );
    assert.match(worksheet, /<dimension ref="A1:R2"\/>/);
    assert.match(worksheet, /001\.002/);

    await page.screenshot({
      path: path.join(outputDirectory, "resultado-filtrado.png"),
      fullPage: true,
    });
    assert.deepEqual(pageErrors, []);

    console.log(JSON.stringify({
      publishedFunctions,
      resultStatuses: statuses,
      filteredRows: 1,
      csv: csvPath,
      xlsx: xlsxPath,
      screenshot: path.join(outputDirectory, "resultado-filtrado.png"),
      portableCatalog: jsonPath,
      convertedOrse: convertedOrsePath,
      pageErrors,
    }, null, 2));
    console.log("Homologação em navegador v4.3.0: aprovada");
  } finally {
    await browser.close();
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
