import { gunzipSync } from "node:zlib";
import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

import { adaptComparisonToLegacyView } from "../src/core/adapt-comparison-to-legacy-view.js";
import { analyzeBudget } from "../src/core/analyze-budget.js";
import { compareBudgetToCatalog } from "../src/core/compare-budget-to-catalog.js";
import { prepareComparisonExport } from "../src/core/prepare-comparison-export.js";
import { prepareReferenceCatalog } from "../src/core/prepare-reference-catalog.js";
import { readWorkbookFile } from "../src/core/read-workbook-file.js";
import { runComparisonFromLegacyState } from "../src/core/run-comparison-from-legacy-state.js";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const sourceRoot = resolve(projectRoot, "../project_sources");
const baselinePath = resolve(
  projectRoot,
  "baseline/sicorp_comparador_orcamento_v4.0.5.html",
);

const realFiles = {
  services: resolve(sourceRoot, "01-Planos-de-Servicos-028-ENC.-SOCIAIS-114-15.xls"),
  budget: resolve(sourceRoot, "02-PLANILHA-OR-AMENT-RIA-COMPLETA-Original-1-.xlsx"),
  inputs: resolve(sourceRoot, "03-Tabela-de-Insumos-028-ENC.-SOCIAIS-114-15.xls"),
  sinapi: resolve(sourceRoot, "04-SINAPI_Refer-ncia_2025_07-1-.xlsx"),
};

async function embeddedSheetJs() {
  const html = await readFile(baselinePath, "utf8");
  const match = html.match(
    /<script id="legacyXlsRuntime"[^>]*>([A-Za-z0-9+/=]+)<\/script>/,
  );
  if (!match) throw new Error("Runtime XLS legado não encontrado na baseline.");

  const source = gunzipSync(Buffer.from(match[1], "base64")).toString("utf8");
  const context = {
    console,
    setTimeout,
    clearTimeout,
    ArrayBuffer,
    DataView,
    Uint8Array,
    Int8Array,
    Uint16Array,
    Int16Array,
    Uint32Array,
    Int32Array,
    Float32Array,
    Float64Array,
    Date,
    Math,
    JSON,
    TextDecoder,
    TextEncoder,
  };
  context.window = context;
  context.self = context;
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(source, context, { filename: "sheetjs-0.18.5.js" });
  if (!context.XLSX?.read || !context.XLSX?.utils) {
    throw new Error("Runtime XLS legado não foi inicializado.");
  }
  return context.XLSX;
}

async function loadWorkbook(xlsx, path) {
  const bytes = await readFile(path);
  return readWorkbookFile({
    fileName: path.split("/").at(-1),
    bytes,
  }, { spreadsheetRuntime: xlsx });
}

function nonEmpty(value) {
  return String(value ?? "").trim() !== "";
}

function inspectWorkbook(label, workbook) {
  console.log(`\n[${label}] ${workbook.fileName}`);
  for (const sheet of workbook.sheets) {
    const nonEmptyRows = sheet.rows.filter((row) => row.some(nonEmpty));
    const maxColumns = nonEmptyRows.reduce((max, row) => Math.max(max, row.length), 0);
    console.log(`- ${sheet.name}: ${nonEmptyRows.length} linhas não vazias; ${maxColumns} colunas`);
    for (const [rowIndex, row] of sheet.rows.entries()) {
      if (!row.some(nonEmpty)) continue;
      console.log(`  linha ${rowIndex + 1}: ${JSON.stringify(row.slice(0, 18))}`);
      if (rowIndex >= 15) break;
    }
  }
}

const xlsx = await embeddedSheetJs();
const workbooks = Object.fromEntries(await Promise.all(
  Object.entries(realFiles).map(async ([key, path]) => [key, await loadWorkbook(xlsx, path)]),
));

assert.equal(workbooks.services.format, "xls");
assert.equal(workbooks.inputs.format, "xls");
assert.equal(workbooks.budget.format, "xlsx");
assert.equal(workbooks.sinapi.format, "xlsx");
assert.ok(workbooks.services.sheets.some((sheet) => sheet.name === "orcamento"));
assert.ok(workbooks.inputs.sheets.some((sheet) => sheet.name === "insumos"));
assert.ok(workbooks.budget.sheets.some((sheet) => sheet.name === "PLANILHA ORCAMENTARIA"));
assert.ok(workbooks.sinapi.sheets.some((sheet) => sheet.name === "ISD"));

if (process.argv.includes("--inspect")) {
  for (const [key, workbook] of Object.entries(workbooks)) inspectWorkbook(key, workbook);
  process.exit(0);
}

const codePolicy = {
  caseInsensitive: true,
  stripSeparators: true,
};
const dependencies = {
  analyzeBudget,
  prepareReferenceCatalog,
  compareBudgetToCatalog,
  adaptComparisonToLegacyView,
};

function configuredBase({
  name,
  sourceIdentifier,
  workbook,
  sheetName,
  headerRow,
  codeCol,
  descCol,
  unitCol,
  valueCol,
  id,
}) {
  return {
    id,
    name,
    sourceIdentifier,
    sourceKey: sourceIdentifier.toLocaleLowerCase("pt-BR"),
    fileName: workbook.fileName,
    workbook,
    sheetNames: [sheetName],
    headerRow,
    codeCol: String(codeCol),
    descCol: String(descCol),
    unitCol: String(unitCol),
    valueCol: String(valueCol),
  };
}

function canonicalBase(legacyBase) {
  return {
    name: legacyBase.name,
    source: legacyBase.sourceIdentifier,
    fileName: legacyBase.fileName,
    sheet: legacyBase.workbook.sheets.find(
      (sheet) => sheet.name === legacyBase.sheetNames[0],
    ),
    headerRowNumber: legacyBase.headerRow,
    mapping: {
      code: legacyBase.codeCol,
      description: legacyBase.descCol,
      unit: legacyBase.unitCol,
      price: legacyBase.valueCol,
    },
  };
}

function regressionCounts(catalog) {
  return {
    acceptedOccurrences: catalog.items.reduce(
      (count, item) => count + Math.max(1, item.origins?.length ?? 0),
      0,
    ),
    canonicalItems: catalog.items.length,
    discarded: catalog.reviewRows.filter((row) => row.treatment === "Removida").length,
    warnings: catalog.reviewRows.filter(
      (row) => row.treatment === "Mantida com alerta",
    ).length,
    repeatedHeaders: catalog.reviewRows.filter(
      (row) => row.reason === "Cabeçalho repetido",
    ).length,
    unavailablePrices: catalog.stats.unavailablePrices,
  };
}

const bases = [
  configuredBase({
    id: 1,
    name: "SEINFRA — Serviços",
    sourceIdentifier: "SEINFRA",
    workbook: workbooks.services,
    sheetName: "orcamento",
    headerRow: 4,
    codeCol: 1,
    descCol: 2,
    unitCol: 5,
    valueCol: 6,
  }),
  configuredBase({
    id: 2,
    name: "SEINFRA — Insumos",
    sourceIdentifier: "SEINFRA",
    workbook: workbooks.inputs,
    sheetName: "insumos",
    headerRow: 6,
    codeCol: 0,
    descCol: 1,
    unitCol: 2,
    valueCol: 3,
  }),
  configuredBase({
    id: 3,
    name: "SINAPI — ISD/CE",
    sourceIdentifier: "SINAPI",
    workbook: workbooks.sinapi,
    sheetName: "ISD",
    headerRow: 10,
    codeCol: 1,
    descCol: 2,
    unitCol: 3,
    valueCol: 10,
  }),
];

const individualCatalogs = bases.map((base) => prepareReferenceCatalog({
  bases: [canonicalBase(base)],
  codePolicy,
}));
const [servicesCatalog, inputsCatalog, sinapiCatalog] = individualCatalogs;

assert.deepEqual(regressionCounts(servicesCatalog), {
  acceptedOccurrences: 4437,
  canonicalItems: 4436,
  discarded: 215,
  warnings: 16,
  repeatedHeaders: 0,
  unavailablePrices: 16,
});
assert.equal(regressionCounts(inputsCatalog).acceptedOccurrences, 11828);
assert.equal(regressionCounts(inputsCatalog).discarded, 91);
assert.equal(regressionCounts(inputsCatalog).repeatedHeaders, 44);
assert.equal(regressionCounts(sinapiCatalog).acceptedOccurrences, 4893);
assert.equal(regressionCounts(sinapiCatalog).discarded, 8);
assert.equal(regressionCounts(sinapiCatalog).unavailablePrices, 2155);

const execution = runComparisonFromLegacyState({
  projectWorkbook: workbooks.budget,
  projectSheetName: "PLANILHA ORCAMENTARIA",
  projectHeaderRow: 2,
  projectMapping: {
    code: "1",
    source: "2",
    description: "3",
    unit: "4",
    quantity: "5",
    priceWithoutBdi: "6",
    bdi: "7",
    priceWithBdi: "8",
  },
  bases,
  tolerance: 0.01,
  codePolicy,
}, dependencies);

assert.equal(execution.budget.stats.accepted, 424);
assert.equal(execution.budget.stats.reviewed, 114);
assert.equal(
  execution.budget.reviewRows.filter((row) => row.reason === "Cabeçalho repetido").length,
  0,
);
assert.equal(
  execution.budget.reviewRows.filter((row) => row.reason === "Título/categoria").length,
  114,
);
assert.equal(execution.view.results.length, 424);
assert.equal(execution.catalog.conflicts.length, 0);
assert.ok(
  Math.abs(execution.comparison.financial.totalWithBdi - 1990067.16) <= 0.001,
  `Total com BDI divergente: ${execution.comparison.financial.totalWithBdi}`,
);
const worksheetGrandTotal = Number(
  workbooks.budget.sheets
    .find((sheet) => sheet.name === "PLANILHA ORCAMENTARIA")
    ?.rows?.[538]?.[9],
);
assert.equal(worksheetGrandTotal, 1990067.18);
assert.ok(
  Math.abs(worksheetGrandTotal - execution.comparison.financial.totalWithBdi - 0.02) <= 0.001,
  "A diferença conhecida de arredondamento hierárquico deixou de ser R$ 0,02.",
);

const preparedExport = prepareComparisonExport({
  results: execution.view.results,
  projectFileName: workbooks.budget.fileName,
  generatedAt: new Date("2026-08-21T12:00:00-03:00"),
});
assert.equal(preparedExport.hasRows, true);
assert.equal(preparedExport.table.columns.length, 18);
assert.equal(preparedExport.table.rows.length, 424);
assert.equal(preparedExport.csv.text.split("\r\n").length, 425);
assert.equal(preparedExport.xlsx.bytes[0], 0x50);
assert.equal(preparedExport.xlsx.bytes[1], 0x4b);
assert.ok(preparedExport.xlsx.bytes.length > 100_000);

const summary = {
  reader: Object.fromEntries(Object.entries(workbooks).map(([key, workbook]) => [key, {
    format: workbook.format,
    sheets: workbook.sheets.length,
  }])),
  services: regressionCounts(servicesCatalog),
  inputs: regressionCounts(inputsCatalog),
  sinapi: regressionCounts(sinapiCatalog),
  budget: {
    headerRow: 2,
    accepted: execution.budget.stats.accepted,
    reviewed: execution.budget.stats.reviewed,
    reviewReasons: {
      titleOrCategory: execution.budget.reviewRows.filter(
        (row) => row.reason === "Título/categoria",
      ).length,
      repeatedHeader: execution.budget.reviewRows.filter(
        (row) => row.reason === "Cabeçalho repetido",
      ).length,
    },
  },
  comparison: {
    results: execution.view.results.length,
    totalWithBdi: execution.comparison.financial.totalWithBdi,
    worksheetGrandTotal,
    hierarchicalRoundingDifference: Number(
      (worksheetGrandTotal - execution.comparison.financial.totalWithBdi).toFixed(2),
    ),
    below: execution.comparison.stats.below,
    equal: execution.comparison.stats.equal,
    above: execution.comparison.stats.above,
    referenceNotFound: execution.comparison.stats.notFound,
    budgetPriceUnavailable: execution.comparison.stats.budgetPriceUnavailable,
    basePriceUnavailable: execution.comparison.stats.basePriceUnavailable,
  },
  export: {
    rows: preparedExport.table.rows.length,
    columns: preparedExport.table.columns.length,
    csvBytes: Buffer.byteLength(preparedExport.csv.text, "utf8"),
    xlsxBytes: preparedExport.xlsx.bytes.length,
    csvFileName: preparedExport.csv.filename,
    xlsxFileName: preparedExport.xlsx.filename,
  },
};

console.log(JSON.stringify(summary, null, 2));

if (process.argv.includes("--write-export")) {
  const outputDirectory = resolve(projectRoot, "../qa-export-real-v4.1.0");
  await mkdir(outputDirectory, { recursive: true });
  await Promise.all([
    writeFile(resolve(outputDirectory, preparedExport.csv.filename), preparedExport.csv.text),
    writeFile(resolve(outputDirectory, preparedExport.xlsx.filename), preparedExport.xlsx.bytes),
  ]);
  console.log(`Exportação real gravada em: ${outputDirectory}`);
}

console.log("Regressão real v4.1.0: aprovada");
