import assert from "node:assert/strict";
import { gunzipSync, inflateSync } from "node:zlib";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

import {
  convertOrseFile,
  writeOrseWorkbookXlsx,
} from "../src/core/convert-orse-file.js";
import { readWorkbookFile } from "../src/core/read-workbook-file.js";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const sourcePath = resolve(projectRoot, "../project_sources/07-20260601-00.ORSE");
const baselinePath = resolve(projectRoot, "baseline/sicorp_comparador_orcamento_v4.0.5.html");
const outputDirectory = resolve(projectRoot, "qa/v4.3.0/orse");

async function embeddedSheetJs() {
  const html = await readFile(baselinePath, "utf8");
  const match = html.match(/<script id="legacyXlsRuntime"[^>]*>([A-Za-z0-9+/=]+)<\/script>/);
  if (!match) throw new Error("Runtime XLS legado não encontrado na baseline.");
  const source = gunzipSync(Buffer.from(match[1], "base64")).toString("utf8");
  const context = {
    console,
    setTimeout,
    clearTimeout,
    ArrayBuffer,
    DataView,
    Uint8Array,
    Int8Array,
    Uint16Array,
    Int16Array,
    Uint32Array,
    Int32Array,
    Float32Array,
    Float64Array,
    Date,
    Math,
    JSON,
    TextDecoder,
    TextEncoder,
  };
  context.window = context;
  context.self = context;
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(source, context, { filename: "sheetjs-0.18.5.js" });
  if (!context.XLSX?.read || !context.XLSX?.write || !context.XLSX?.utils) {
    throw new Error("Runtime XLS/XLSX legado não foi inicializado.");
  }
  return context.XLSX;
}

const [bytes, spreadsheetRuntime] = await Promise.all([
  readFile(sourcePath),
  embeddedSheetJs(),
]);

const converted = await convertOrseFile({
  fileName: "20260601-00.ORSE",
  bytes,
}, {
  inflateZlib: (compressed) => new Uint8Array(inflateSync(compressed)),
  yieldControl: async () => {},
});

assert.equal(converted.outputFileName, "20260601-00_ORSE.xlsx");
assert.deepEqual(converted.data.period, { year: 2026, month: 6, order: 1 });
assert.equal(converted.data.stats.inputs.total, 8087);
assert.equal(converted.data.stats.services.total, 9931);
assert.deepEqual(converted.workbook.sheets.map((sheet) => sheet.name), ["Insumos", "Servicos"]);
assert.deepEqual(converted.exportWorkbook.sheets.map((sheet) => sheet.name), ["Resumo", "Insumos", "Servicos"]);
assert.equal(converted.workbook.sheets[0].rows.length, 8088);
assert.equal(converted.workbook.sheets[1].rows.length, 9932);

const xlsxBytes = writeOrseWorkbookXlsx(converted.exportWorkbook, spreadsheetRuntime);
assert.equal(xlsxBytes[0], 0x50);
assert.equal(xlsxBytes[1], 0x4b);
const reimported = readWorkbookFile({
  fileName: converted.outputFileName,
  bytes: xlsxBytes,
}, { spreadsheetRuntime });
assert.deepEqual(reimported.sheets.map((sheet) => sheet.name), ["Resumo", "Insumos", "Servicos"]);
assert.equal(reimported.sheets.find((sheet) => sheet.name === "Insumos").rows.length, 8088);
assert.equal(reimported.sheets.find((sheet) => sheet.name === "Servicos").rows.length, 9932);

await mkdir(outputDirectory, { recursive: true });
const outputPath = resolve(outputDirectory, converted.outputFileName);
await writeFile(outputPath, xlsxBytes);

console.log(JSON.stringify({
  input: sourcePath,
  period: converted.data.period,
  inputs: converted.data.stats.inputs,
  services: converted.data.stats.services,
  workbookSheets: reimported.sheets.map((sheet) => ({ name: sheet.name, rows: sheet.rows.length })),
  xlsxBytes: xlsxBytes.length,
  output: outputPath,
}, null, 2));
console.log("Regressão ORSE real v4.3.0: aprovada");
