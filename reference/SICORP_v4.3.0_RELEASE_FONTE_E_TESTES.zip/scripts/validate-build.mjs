import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

import {
  consolidateSingleHtml,
  insertBeforeUniqueAnchor,
} from "../src/build/consolidate-single-html.js";
import { integratePriceSourceCentralHtml } from "../src/build/integrate-price-source-central-html.js";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const baselinePath = resolve(
  projectRoot,
  "baseline/sicorp_comparador_orcamento_v4.0.5.html",
);
const distPath = resolve(
  projectRoot,
  "dist/sicorp_comparador_orcamento_v4.3.0.html",
);
const expectedBaselineHash =
  "be2c883baf4b4611d9ea2cefced7c4973587dfa8aac952271a6e21ddc389a7b8";
const appScriptAnchor = '  <script>\n    "use strict";';
const startMarker = "  <!-- SICORP_V42_CORE_START -->";
const endMarker = "  <!-- SICORP_V42_CORE_END -->";
const uiStartMarker = "  <!-- SICORP_V42_PRICE_SOURCE_RUNTIME_START -->";
const uiEndMarker = "  <!-- SICORP_V42_PRICE_SOURCE_RUNTIME_END -->";
const integrationStartMarker = "    /* SICORP_V41_INTEGRATION_START */";
const integrationEndMarker = "    /* SICORP_V41_INTEGRATION_END */";
const exportIntegrationStartMarker = "    /* SICORP_V41_EXPORT_INTEGRATION_START */";
const exportIntegrationEndMarker = "    /* SICORP_V41_EXPORT_INTEGRATION_END */";
const readerIntegrationStartMarker = "    /* SICORP_V41_READER_INTEGRATION_START */";
const readerIntegrationEndMarker = "    /* SICORP_V41_READER_INTEGRATION_END */";

function sha256(content) {
  return createHash("sha256").update(content).digest("hex");
}

function markedBlock(source, startMarkerText, endMarkerText, label) {
  const start = source.indexOf(startMarkerText);
  const duplicateStart = source.indexOf(startMarkerText, start + startMarkerText.length);
  const end = source.indexOf(endMarkerText, start + startMarkerText.length);
  assert.notEqual(start, -1, `Marcador inicial de ${label} não encontrado.`);
  assert.equal(duplicateStart, -1, `Marcador inicial de ${label} duplicado.`);
  assert.notEqual(end, -1, `Marcador final de ${label} não encontrado.`);
  const endExclusive = end + endMarkerText.length;
  const newline = source[endExclusive] === "\n" ? "\n" : "";
  return source.slice(start, endExclusive) + newline;
}

const [baseline, output] = await Promise.all([
  readFile(baselinePath, "utf8"),
  readFile(distPath, "utf8"),
]);

assert.equal(
  sha256(baseline),
  expectedBaselineHash,
  "A baseline v4.0.5 foi modificada.",
);

const coreBlock = markedBlock(output, startMarker, endMarker, "módulo");
const priceSourceUiBlock = markedBlock(
  output,
  uiStartMarker,
  uiEndMarker,
  "interface da Central de Bases",
);
const comparisonIntegration = markedBlock(
  output,
  integrationStartMarker,
  integrationEndMarker,
  "integração de comparação",
);
const exportIntegration = markedBlock(
  output,
  exportIntegrationStartMarker,
  exportIntegrationEndMarker,
  "integração de exportação",
);
const readerIntegration = markedBlock(
  output,
  readerIntegrationStartMarker,
  readerIntegrationEndMarker,
  "integração de leitura",
);
const consolidatedBaseline = consolidateSingleHtml(baseline, {
  readerIntegration,
  comparisonIntegration,
  exportIntegration,
});
const integratedBaseline = integratePriceSourceCentralHtml(consolidatedBaseline);
const expectedOutput = insertBeforeUniqueAnchor(
  integratedBaseline,
  appScriptAnchor,
  `${coreBlock}${priceSourceUiBlock}`,
);

assert.equal(
  output,
  expectedOutput,
  "O build alterou conteúdo fora das cinco substituições e do bloco modular autorizados.",
);
assert.match(output, /globalThis\.SicorpCore\s*=\s*Object\.freeze/);
assert.match(output, /function readWorkbookFile\s*\(/);
assert.match(output, /function convertOrseFile\s*\(/);
assert.match(output, /function writeOrseWorkbookXlsx\s*\(/);
assert.match(output, /function analyzeBudget\s*\(/);
assert.match(output, /function prepareReferenceCatalog\s*\(/);
assert.match(output, /function compareBudgetToCatalog\s*\(/);
assert.match(output, /function adaptComparisonToLegacyView\s*\(/);
assert.match(output, /function runComparisonFromLegacyState\s*\(/);
assert.match(output, /function prepareComparisonExport\s*\(/);
assert.match(output, /function createPriceSourceCentral\s*\(/);
assert.match(output, /function installPriceSourceCentralUi\s*\(/);
assert.doesNotMatch(output, /\b(?:loadWorkbook|compare|exportCsv|exportXlsx|copyTable)Legacy\b/);
assert.equal(output.match(/    async function loadWorkbook\s*\(/g)?.length, 1);
assert.equal(output.match(/    function compare\s*\(/g)?.length, 1);
assert.equal(output.match(/    function exportCsv\s*\(/g)?.length, 1);
assert.equal(output.match(/    function exportXlsx\s*\(/g)?.length, 1);
assert.equal(output.match(/    async function copyTable\s*\(/g)?.length, 1);
assert.match(output, /SicorpCore\.runComparisonFromLegacyState\s*\(/);
assert.match(output, /SicorpCore\.prepareComparisonExport\s*\(/);
assert.match(output, /SicorpCore\.readWorkbookFile\s*\(/);
assert.match(output, /SicorpCore\.createPriceSourceCentral/);
assert.match(output, /SicorpPriceSourceUi\.installPriceSourceCentralUi/);
assert.equal(output.match(/id="priceSourceSearch"/g)?.length, 1);
assert.equal(output.match(/id="priceSourceLinks"/g)?.length, 1);
assert.equal(output.match(/id="priceSourceEditorForm"/g)?.length, 1);
assert.match(output, /Versão 4\.3\.0 · Comparador offline/);
assert.match(output, /id="priceSourceUrl" type="text" required[^>]*placeholder="https:\/\/"/);
assert.doesNotMatch(output, /Pode ser informado com ou sem https:\/\//);
assert.doesNotMatch(output, /\bCASAN\b/);
assert.doesNotMatch(output, /"versao"\s*:/);
assert.match(output, /id="priceSourceUnknown"/);
assert.match(output, /Não identificadas automaticamente:/);
assert.match(output, /base\(s\) identificada\(s\) no orçamento/);
assert.doesNotMatch(output, /identificada\(s\) automaticamente no orçamento/);
assert.doesNotMatch(output, /\baliases\b/);
assert.doesNotMatch(output, /result\.total === result\.identifiedIds\.length/);
assert.match(output, /Sugestão para/);
assert.doesNotMatch(output, /Identificada sem separadores|Identificada diretamente/);
assert.doesNotMatch(output, /price-source-match-badge\.family/);
assert.match(output, /\.price-source-unknown \{[\s\S]*?display: inline-block;[\s\S]*?width: fit-content;[\s\S]*?background: #eff6ff;[\s\S]*?color: #1d4ed8;/);
assert.match(output, /DER-ES_Edif/);
assert.match(output, /https:\/\/der\.es\.gov\.br\/referencial-de-precos-edificacoes/);
assert.match(output, /DER-ES_Rodo/);
assert.match(output, /https:\/\/der\.es\.gov\.br\/referencial-de-precos-rodovias/);
assert.match(output, /Departamento de Estradas de Rodagem da Paraíba/);
assert.match(output, /https:\/\/www\.der\.pb\.gov\.br\/informacoes\/tabela-de-precos-der-pb/);
assert.match(output, /Secretaria de Estado de Obras Públicas do Pará/);
assert.match(output, /https:\/\/www\.seop\.pa\.gov\.br\/planilha-de-custo/);
assert.match(output, /id="blockingDialog"/);
assert.match(output, /id="blockingDialogReturn"[^>]*>Retornar</);
assert.match(output, /function showBlockingIssue/);
assert.doesNotMatch(output, /id="projectNextBtn"[^>]*disabled/);
assert.doesNotMatch(output, /id="basesNextBtn"[^>]*disabled/);
assert.doesNotMatch(output, /Identificadores de fonte encontrados/);
assert.match(output, /id="projectSourceIdentifiers" class="hidden"/);
assert.match(output, /header: "Quantidade"/);
assert.match(output, /Agência Estadual de Gestão de Empreendimentos de MS/);
assert.match(output, /accept="\.xlsx,\.xls,\.csv,\.txt,\.orse"/);
assert.match(output, /Planilhas XLSX, XLS, CSV, TXT ou ORSE/);
assert.match(output, /SicorpCore\.convertOrseFile\s*\(/);
assert.match(output, /SicorpCore\.writeOrseWorkbookXlsx\s*\(/);
assert.match(output, /converted\.outputFileName/);
assert.equal(output.match(/Até 2 linhas anteriores \+ cabeçalho \+ até 11 itens/g)?.length, 2);
assert.match(output, /Math\.max\(0, safeHeaderIndex - 2\)/);
assert.match(output, /if \(showAll\) visibleCards\.push\(createAddCard\(\)\)/);
assert.match(output, /flex-wrap: nowrap/);
assert.match(output, /font-size: \.75em/);
assert.match(output, /Linhas que não são consideradas itens são identificadas e removidas da planilha/);
assert.doesNotMatch(output, /Linhas estruturais são separadas dos itens/);
assert.match(output, /https:\/\/www\.der\.mg\.gov\.br\/536-obras\/sistema-referencial-de-custos/);
assert.match(
  output,
  /formatCode="&quot;R\$&quot; #,##0\.00;\[Red\]-&quot;R\$&quot; #,##0\.00"/,
);
assert.doesNotMatch(output, /formatCode="&quot;R\s+<script>/);
assert.doesNotMatch(output, /<script[^>]+src\s*=/i);

const inlineScripts = [...output.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
assert.ok(inlineScripts.length >= 2, "Scripts inline do núcleo e da interface não encontrados.");
for (const [index, match] of inlineScripts.entries()) {
  assert.doesNotThrow(
    () => new vm.Script(match[1], { filename: `sicorp-inline-${index + 1}.js` }),
    `O script inline ${index + 1} contém JavaScript inválido.`,
  );
}

console.log("Baseline v4.0.5: íntegra");
console.log("Bloco modular e Central de Bases: incorporados antes do script da interface");
console.log("Consolidação: cinco fallbacks legados ausentes");
console.log("Integração: leitura, comparação e exportações possuem entrada canônica única");
console.log(`JavaScript inline: ${inlineScripts.length} blocos sintaticamente válidos`);
console.log("Dependências externas de script: nenhuma");
console.log(`HTML final: ${output.length} caracteres`);
console.log(`SHA-256 do build: ${sha256(output)}`);
